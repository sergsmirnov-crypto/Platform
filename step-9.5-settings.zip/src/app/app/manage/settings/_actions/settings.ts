'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'

import { requirePermission } from '@/modules/access'
import { resetSetting, updateSetting } from '@/modules/audit'
import { getRequestOrigin } from '@/modules/identity/cookie'
import { getSession } from '@/modules/identity/current-user'
import { hashClientIp } from '@/modules/identity/service'
import { errors } from '@/shared/errors'
import { routes } from '@/shared/routes'
import { defineAction } from '@/shared/server'

/**
 * Сохранение настроек платформы.
 *
 * ─────────────────────────────────────────────────────────────────
 * ЕДИНСТВЕННОЕ МЕСТО В ПРОЕКТЕ, ГДЕ ПРАВО ПРОВЕРЯЕТСЯ В ДЕЙСТВИИ
 *
 * Обычно `requirePermission` стоит в сервисе модуля. Здесь нельзя:
 * модуль `access` уже импортирует `audit`, чтобы писать выдачу прав
 * в журнал, и обратный импорт замкнул бы два модуля в кольцо.
 *
 * Проверка от этого не слабее — действие тоже выполняется на сервере
 * и остаётся единственным входом снаружи, — но она менее заметна.
 * Правильное лечение описано в `settings.admin.ts`: вынести настройки
 * из `audit` в собственный модуль.
 * ─────────────────────────────────────────────────────────────────
 */

async function actor(): Promise<{ userId: string; ipHash: string | null }> {
  const session = await getSession()
  if (!session) throw errors.unauthorized()

  const origin = await getRequestOrigin()

  await requirePermission(session.user.id, 'settings.edit')

  return { userId: session.user.id, ipHash: hashClientIp(origin.ip) }
}

/**
 * Сброс кэша страниц, на которых видны настройки.
 *
 * Их четыре, и это не очевидно: карточки чатов стоят и на главной,
 * и на странице чатов, а ссылка продления — на экране закончившейся
 * подписки и в настройках профиля. Без перечисления человек правит
 * текст, обновляет страницу и видит старый.
 */
function revalidateSettings(): void {
  revalidatePath(routes.app.dashboard())
  revalidatePath(routes.app.club.about())
  revalidatePath(routes.app.club.telegram())
  revalidatePath(routes.app.me.settings())
  revalidatePath(routes.app.manage.settings())
}

export const saveSettingAction = defineAction({
  name: 'settings.save',
  input: z.object({
    key: z.string().min(1),
    /** Значение проверяется схемой настройки в модуле, а не здесь */
    value: z.unknown(),
  }),
  handler: async ({ key, value }) => {
    const { userId, ipHash } = await actor()

    await updateSetting(userId, key, value, { ipHash })
    revalidateSettings()

    return { key }
  },
})

export const resetSettingAction = defineAction({
  name: 'settings.reset',
  input: z.object({
    key: z.enum(['telegram.chats', 'subscription.renew_url', 'club.about']),
  }),
  handler: async ({ key }) => {
    const { userId, ipHash } = await actor()

    await resetSetting(userId, key, { ipHash })
    revalidateSettings()

    return { key }
  },
})
