import { PagePlaceholder } from '../_components/page-placeholder'

export const metadata = { title: 'Личный кабинет' }

export default function MePage() {
  return (
    <PagePlaceholder
      title="Личный кабинет"
      stage="Этап 4"
      description="Профиль, прогресс, избранное, настройки."
    />
  )
}
