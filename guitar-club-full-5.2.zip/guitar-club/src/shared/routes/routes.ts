/**
 * Реестр адресов страниц — единственный источник истины по URL проекта.
 *
 * Зачем это нужно вместо строк прямо в коде:
 *
 * 1. Переименовать раздел («Разборы» → «Библиотека») можно правкой одного
 *    файла, а не поиском по всему проекту.
 * 2. Опечатка в адресе становится ошибкой сборки, а не битой ссылкой,
 *    которую заметит участник клуба.
 * 3. Открыв этот файл, новый разработчик видит карту всего продукта.
 *
 * Правило: в компонентах и модулях адреса пишутся ТОЛЬКО через `routes`.
 * Строковых литералов вида '/app/learn/songs' в коде быть не должно.
 */

export const routes = {
  /** Лендинг и экран входа */
  home: () => '/',

  auth: {
    /** Возврат из виджета Telegram после входа */
    telegram: () => '/auth/telegram',
  },

  legal: {
    offer: () => '/legal/offer',
    privacy: () => '/legal/privacy',
    contacts: () => '/legal/contacts',
  },

  /** Закрытая зона. Всё, что внутри, требует активной сессии. */
  app: {
    dashboard: () => '/app',
    onboarding: () => '/app/onboarding',
    search: () => '/app/search',
    subscriptionExpired: () => '/app/subscription/expired',

    learn: {
      index: () => '/app/learn',
      songs: () => '/app/learn/songs',
      song: (slug: string) => `/app/learn/songs/${slug}`,
      course: () => '/app/learn/course',
      courseModule: (moduleSlug: string) => `/app/learn/course/${moduleSlug}`,
      lesson: (moduleSlug: string, lessonSlug: string) =>
        `/app/learn/course/${moduleSlug}/${lessonSlug}`,
    },

    streams: {
      index: () => '/app/streams',
      upcoming: () => '/app/streams/upcoming',
      stream: (slug: string) => `/app/streams/${slug}`,
    },

    club: {
      index: () => '/app/club',
      about: () => '/app/club/about',
      curators: () => '/app/club/curators',
      curator: (slug: string) => `/app/club/curators/${slug}`,
      news: () => '/app/club/news',
      newsPost: (slug: string) => `/app/club/news/${slug}`,
      telegram: () => '/app/club/telegram',
    },

    me: {
      index: () => '/app/me',
      profile: () => '/app/me/profile',
      progress: () => '/app/me/progress',
      favorites: () => '/app/me/favorites',
      notes: () => '/app/me/notes',
      settings: () => '/app/me/settings',
    },

    /**
     * Управление. Не отдельная админка, а раздел платформы:
     * появляется в меню только при наличии соответствующих прав (PRD v0.3).
     */
    manage: {
      index: () => '/app/manage',
      songs: () => '/app/manage/songs',
      song: (id: string) => `/app/manage/songs/${id}`,
      /** Экран массовой разметки материалов, перенесённых из Telegram */
      migration: () => '/app/manage/migration',
      streams: () => '/app/manage/streams',
      course: () => '/app/manage/course',
      news: () => '/app/manage/news',
      media: () => '/app/manage/media',
      curators: () => '/app/manage/curators',
      team: () => '/app/manage/team',
      members: () => '/app/manage/members',
      subscriptions: () => '/app/manage/subscriptions',
      settings: () => '/app/manage/settings',
      logs: () => '/app/manage/logs',
    },
  },

  /**
   * Служебные страницы для разработки.
   * В производственной сборке отвечают 404.
   */
  dev: {
    routes: () => '/dev/routes',
    ui: () => '/dev/ui',
    login: () => '/dev/login',
  },
} as const
