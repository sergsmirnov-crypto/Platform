import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

type Props = { params: Promise<{ slug: string }> }

export const metadata = { title: 'Новость' }

export default async function NewsPostPage({ params }: Props) {
  const { slug } = await params

  return (
    <PagePlaceholder
      title="Новость"
      stage="Этап 8"
      description="Пост из ленты клуба."
      values={[{ label: 'slug', value: slug }]}
    />
  )
}
