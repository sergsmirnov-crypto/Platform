import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Новости клуба' }

export default function NewsPage() {
  return (
    <PagePlaceholder title="Новости клуба" stage="Этап 8" description="Что происходит в клубе." />
  )
}
