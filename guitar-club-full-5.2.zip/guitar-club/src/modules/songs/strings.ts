/**
 * Тексты интерфейса, связанные с разборами.
 *
 * Лежат рядом с модулем, а не в компонентах: формулировки каталога
 * правятся чаще разметки, и искать их по десятку файлов не должно быть
 * нужно.
 */
export const songStrings = {
  catalog: {
    title: 'Разборы',
    description: 'Библиотека разборов клуба',
    searchPlaceholder: 'Песня или исполнитель',
    reset: 'Сбросить фильтры',
    found: (total: number) => `Найдено: ${total}`,
    empty: 'По этим условиям ничего не нашлось',
    emptyHint: 'Попробуйте убрать часть фильтров или поискать по названию',
    emptyCatalog: 'Разборов пока нет',
    emptyCatalogHint: 'Первые появятся, как только кураторы перенесут их из Telegram',
  },

  filters: {
    level: 'Уровень',
    tuning: 'Строй',
    genre: 'Жанр',
    technique: 'Техника',
    curator: 'Куратор',
    sort: 'Порядок',
  },

  song: {
    levelSwitch: 'Уровень разбора',
    structure: 'Структура разбора',
    materials: 'Материалы',
    similar: 'Похожие разборы',
    noVideo: 'Видео пока не загружено',
    noArrangements: 'Разбор ещё готовится',
    curator: 'Куратор',
    progress: (done: number, total: number) => `Прогресс: ${done} из ${total}`,
  },

  properties: {
    tuning: 'Строй',
    capo: 'Каподастр',
    tempo: 'Темп',
    key: 'Тональность',
    capoValue: (fret: number) => (fret > 0 ? `${fret} лад` : 'без каподастра'),
    tempoValue: (bpm: number) => `${bpm} уд/мин`,
  },

  status: {
    draft: 'Черновик',
    scheduled: 'Запланировано',
    archived: 'В архиве',
  },
} as const
