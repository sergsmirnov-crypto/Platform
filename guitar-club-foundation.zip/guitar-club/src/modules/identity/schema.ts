import {
  boolean,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  uniqueIndex,
} from 'drizzle-orm/pg-core'
import { uuid } from 'drizzle-orm/pg-core'

import { createdAt, deletedAt, primaryId, timestampTz, updatedAt } from '@/shared/db/columns'

/**
 * Пользователи, способы входа и сессии.
 *
 * Ключевое решение: способ входа вынесен из таблицы пользователей
 * в отдельную таблицу `auth_identities`. Причина — в PRD v0.1 §0, пункт 1:
 * Telegram не должен быть единственной дверью в оплаченный контент.
 * Добавить вход по почте или ключу доступа позже можно будет без изменения
 * структуры, просто новой строкой.
 */

export const skillLevelEnum = pgEnum('skill_level', ['beginner', 'intermediate', 'advanced'])
export const authProviderEnum = pgEnum('auth_provider', ['telegram', 'email', 'passkey'])

export const users = pgTable(
  'users',
  {
    id: primaryId(),

    displayName: text('display_name').notNull(),
    avatarUrl: text('avatar_url'),
    city: text('city'),
    bio: text('bio'),

    /** Год начала игры на гитаре — для подбора материалов по уровню */
    playingSince: integer('playing_since'),
    skillLevel: skillLevelEnum('skill_level'),

    /** Ссылки на соцсети: { vk, youtube, ... } */
    socials: jsonb('socials').$type<Record<string, string>>().notNull().default({}),
    /** Цели из онбординга */
    goals: text('goals').array().notNull().default([]),

    onboardingStep: integer('onboarding_step').notNull().default(0),
    onboardingDoneAt: timestampTz('onboarding_done_at'),

    /** Личные настройки: тема, уведомления, автовоспроизведение */
    settings: jsonb('settings').$type<Record<string, unknown>>().notNull().default({}),

    createdAt: createdAt(),
    updatedAt: updatedAt(),
    lastSeenAt: timestampTz('last_seen_at'),
    deletedAt: deletedAt(),
  },
  (table) => [index('users_last_seen_idx').on(table.lastSeenAt)],
)

export const authIdentities = pgTable(
  'auth_identities',
  {
    id: primaryId(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    provider: authProviderEnum('provider').notNull(),
    /** Идентификатор человека у поставщика входа: telegram_id или адрес почты */
    providerUserId: text('provider_user_id').notNull(),
    /** Дополнительные данные от поставщика: имя пользователя, фото */
    providerData: jsonb('provider_data').$type<Record<string, unknown>>().notNull().default({}),

    isPrimary: boolean('is_primary').notNull().default(false),
    verifiedAt: timestampTz('verified_at'),

    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (table) => [
    // Один и тот же аккаунт Telegram не может быть привязан к двум людям
    uniqueIndex('auth_identities_provider_user_idx').on(table.provider, table.providerUserId),
    index('auth_identities_user_idx').on(table.userId),
  ],
)

export const sessions = pgTable(
  'sessions',
  {
    id: primaryId(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    /**
     * В базе лежит не сам ключ сессии, а его хеш.
     * Если содержимое базы утечёт, войти по этим данным будет нельзя.
     */
    tokenHash: text('token_hash').notNull(),

    /** Для списка активных устройств в профиле */
    userAgent: text('user_agent'),
    /** IP хранится хешированным: адрес — персональные данные */
    ipHash: text('ip_hash'),

    createdAt: createdAt(),
    lastUsedAt: timestampTz('last_used_at').notNull().defaultNow(),
    expiresAt: timestampTz('expires_at').notNull(),
    revokedAt: timestampTz('revoked_at'),
  },
  (table) => [
    uniqueIndex('sessions_token_hash_idx').on(table.tokenHash),
    index('sessions_user_idx').on(table.userId),
    index('sessions_expires_idx').on(table.expiresAt),
  ],
)
