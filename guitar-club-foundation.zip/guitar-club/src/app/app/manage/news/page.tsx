import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Новости: управление' }

export default function ManageNewsPage() {
  return (
    <PagePlaceholder
      title="Новости: управление"
      stage="Этап 8"
      description="Редактор новостей с отложенной публикацией."
    />
  )
}
