import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Разборы: управление' }

export default function ManageSongsPage() {
  return (
    <PagePlaceholder
      title="Разборы: управление"
      stage="Этап 5"
      description="Список разборов с фильтрами по статусу и куратору."
    />
  )
}
