import { JOB_QUEUES } from './queue'

/**
 * Задачи по расписанию.
 *
 * Время указано в формате cron. Все расписания собраны здесь, а не разбросаны
 * по коду: иначе через полгода никто не сможет ответить на вопрос
 * «что и когда у нас запускается».
 */
export type Schedule = {
  queue: string
  /** Формат: минута час день месяц день_недели */
  cron: string
  description: string
}

export const SCHEDULES: Schedule[] = [
  {
    queue: JOB_QUEUES.HEARTBEAT,
    cron: '*/5 * * * *',
    description: 'Каждые 5 минут — отметка, что фоновые задачи живы',
  },
  {
    queue: JOB_QUEUES.SESSION_CLEANUP,
    cron: '30 3 * * *',
    description: 'Каждую ночь в 3:30 — уборка истёкших и закрытых сессий',
  },
  {
    queue: JOB_QUEUES.SUBSCRIPTION_EXPIRE,
    cron: '0 3 * * *',
    description: 'Каждую ночь в 3:00 — закрытие доступа с истёкшим сроком',
  },
  // Появится на шаге 2.5 вместе с вебхуками:
  // {
  //   queue: JOB_QUEUES.SUBSCRIPTION_RECONCILE,
  //   cron: '0 4 * * *',
  //   description: 'Каждую ночь в 4:00 — сверка подписок с Telegram',
  // },
]
