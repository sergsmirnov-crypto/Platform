/**
 * Публичный вход в дизайн-систему.
 *
 * Компоненты отсюда ничего не знают о бизнес-логике: данные приходят
 * через свойства. Это проверяется линтером — `ui/` не может импортировать
 * бизнес-модули.
 */
export { Button, buttonVariants } from './primitives/button'
export type { ButtonProps } from './primitives/button'
export { LinkButton } from './primitives/link-button'
export type { LinkButtonProps } from './primitives/link-button'

export { Card, CardBody, CardTitle, CardMeta, CardActions } from './primitives/card'
export { Badge } from './primitives/badge'
export type { BadgeProps } from './primitives/badge'
export { Input, Textarea, Label, Field } from './primitives/input'
export { ProgressMarker } from './primitives/progress-marker'
export { Skeleton } from './primitives/skeleton'

export { EmptyState } from './patterns/empty-state'
export { PageHeader } from './patterns/page-header'
export { Wave } from './patterns/wave'
export { PagePlaceholder } from './patterns/page-placeholder'

export { cn } from './lib/cn'
