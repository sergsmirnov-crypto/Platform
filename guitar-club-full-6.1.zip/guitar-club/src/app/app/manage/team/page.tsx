import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Команда' }

export default function TeamPage() {
  return (
    <PagePlaceholder
      title="Команда"
      stage="Этап 9"
      description="Роли и персональные права кураторов."
    />
  )
}
