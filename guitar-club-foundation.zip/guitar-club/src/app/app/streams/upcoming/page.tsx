import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Ближайшие эфиры' }

export default function UpcomingStreamsPage() {
  return (
    <PagePlaceholder
      title="Ближайшие эфиры"
      stage="Этап 7"
      description="Расписание и напоминания."
    />
  )
}
