import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Подписки' }

export default function ManageSubscriptionsPage() {
  return (
    <PagePlaceholder
      title="Подписки"
      stage="Этап 9"
      description="Статусы, ручная выдача доступа, расхождения после сверки."
    />
  )
}
