import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Главная' }

export default function DashboardPage() {
  return (
    <PagePlaceholder
      title="Главная"
      stage="Этап 3"
      description="Карточка «Продолжить», новинки, ближайший эфир, переходы в чаты."
    />
  )
}
