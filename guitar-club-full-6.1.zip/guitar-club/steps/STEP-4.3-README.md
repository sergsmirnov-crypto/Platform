# Шаг 4.3 — Фотография профиля

## Применение

```bash
unzip -o step-4.3-avatar.zip -d /путь/к/guitar-club
cd /путь/к/guitar-club
pnpm install        # ⚠️ обязательно: новая зависимость sharp
pnpm db:migrate     # ⚠️ обязательно: миграция 0003
pnpm check && pnpm build
```

Ожидается: **260 тестов**, ошибок нет, сборка успешна.

> ⚠️ Архивы 4.1 и 4.2 должны быть применены раньше.

### Если сборка ругается на `/auth/telegram`

```
Conflicting route and page at /auth/telegram
```

Значит, со времён шага 2.3 остался лишний файл. Удалить:

```bash
rm src/app/\(public\)/auth/telegram/page.tsx
```

Это не связано с 4.3 — обнаружилось при пробной сборке.

## Миграция

`drizzle/0003_avatar.sql`:

```sql
ALTER TABLE "users" ADD COLUMN "avatar_id" text;
ALTER TABLE "users" ADD COLUMN "avatar_updated_at" timestamp with time zone;
ALTER TABLE "users" DROP COLUMN "avatar_url";
```

В удалённой колонке лежали ссылки на снимки из Telegram, которые
по твоему решению не показывались. Терять нечего.

## Что проверить в браузере

```bash
docker compose up -d && pnpm db:migrate && pnpm db:seed && pnpm dev
```

Открыть `/app/me/profile`.

| Действие                                   | Ожидание                                                 |
| ------------------------------------------ | -------------------------------------------------------- |
| Карточка «Фотография» вверху страницы      | Силуэт и кнопка «Загрузить фото»                         |
| Выбрать снимок                             | Откроется окно кадрирования с круглой подсказкой         |
| Тянуть снимок мышью                        | Кадр двигается, пустых углов не появляется никогда       |
| Ползунок масштаба до упора влево           | Снимок ровно накрывает квадрат, сдвинуть его нельзя      |
| Стрелки клавиатуры по области кадрирования | Кадр двигается — без мыши тоже работает                  |
| Esc                                        | Окно закрывается, ничего не сохраняется                  |
| «Сохранить»                                | Фотография появляется в карточке, в шапке и на `/app/me` |
| Обновить страницу                          | Фотография на месте                                      |
| Заменить фотографию                        | Новая появляется сразу, старая нигде не остаётся         |
| «Удалить» → подтвердить                    | Возвращается силуэт                                      |
| Выбрать файл больше 5 МБ                   | Отказ до отправки, с указанием предела                   |
| Переименовать `.pdf` в `.jpg` и выбрать    | Отказ уже от сервера: «Не удалось прочитать изображение» |
| Телефонная ширина                          | Окно во весь экран, кадрирование двумя пальцами          |
| Папка `.storage/public/avatars/` в проекте | Два файла `.webp` на каждую загрузку: 512 и 128 точек    |

### Проверка обещания про данные съёмки

Взять снимок с телефона, у которого включена геометка, загрузить,
скачать получившийся файл из `.storage` и посмотреть его свойства:
координат, модели камеры и даты съёмки там быть не должно.

То же самое проверяет тест `process-image.test.ts` → «стирает данные
съёмки, включая координаты».

## Разовое действие при развёртывании

В панели провайдера хранилища открыть публичный доступ **только**
к префиксу `public/` (это уже описано в шаге 4.2). Без этого фотографии
не будут открываться на боевом сервере, хотя загружаться будут.

## Состав

**Новые файлы**

```
src/shared/images/process-image.ts            пересборка картинки
src/shared/images/process-image.test.ts       10 тестов
src/modules/identity/avatar.ts                размеры, имена файлов, проверки
src/modules/identity/avatar.test.ts           20 тестов
src/modules/identity/avatar-url.ts            сборка адреса
src/modules/identity/avatar-storage.ts        запись и удаление файлов
src/ui/lib/crop-geometry.ts                   математика кадра
src/ui/lib/crop-geometry.test.ts              16 тестов
src/ui/lib/crop-to-blob.ts                    вырезание кадра в браузере
src/ui/primitives/dialog.tsx                  модальное окно
src/ui/primitives/image-cropper.tsx           кадратор
src/app/app/me/_components/avatar-card.tsx    карточка фотографии
src/app/app/me/_components/avatar-editor.tsx  окно кадрирования
drizzle/0003_avatar.sql                       миграция
docs/adr/0010-avatar-pipeline.md              обоснование решений
```

**Изменённые файлы**

```
src/modules/identity/schema.ts        avatar_url → avatar_id, avatar_updated_at
src/modules/identity/repository.ts    чтение и запись фотографии
src/modules/identity/actions.ts       uploadAvatar, removeAvatar
src/modules/identity/telegram-login.ts  фото из Telegram больше не подставляется
src/modules/identity/strings.ts, index.ts
src/app/app/me/profile/page.tsx       карточка вместо заглушки
src/ui/primitives/avatar.tsx          размер xl
src/ui/index.ts
next.config.ts                        sharp + предел размера действия
package.json                          sharp
docs/CHANGELOG.md, DATABASE.md, COMPONENTS.md, API.md, DECISIONS.md, ROADMAP.md
```

**Коммит**

```
feat(profile): add avatar upload with cropping
```
