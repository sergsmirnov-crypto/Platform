import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Мои заметки' }

export default function NotesPage() {
  return (
    <PagePlaceholder
      title="Мои заметки"
      stage="Этап 10"
      description="Личные заметки с привязкой к таймкодам видео."
    />
  )
}
