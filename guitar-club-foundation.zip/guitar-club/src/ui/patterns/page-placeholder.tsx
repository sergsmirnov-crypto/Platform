/**
 * Временная заглушка страницы.
 *
 * Используется на шаге F1, пока страницы не наполнены содержимым.
 * Показывает, что это за экран и на каком этапе он будет реализован, —
 * так по каркасу можно кликать и проверять структуру продукта.
 *
 * Оформление намеренно минимальное: дизайн-система появится на шаге F5,
 * и тогда этот компонент заменят настоящие пустые состояния.
 */

type PagePlaceholderProps = {
  /** Название экрана, как оно будет выглядеть для участника */
  title: string
  /** Когда экран будет реализован: «Этап 5», «шаг F7» */
  stage: string
  /** Что здесь будет */
  description?: string
  /** Значения параметров адреса, если страница динамическая */
  values?: { label: string; value: string }[]
}

export function PagePlaceholder({ title, stage, description, values }: PagePlaceholderProps) {
  return (
    <section className="mx-auto max-w-2xl px-6 py-10">
      <p className="text-xs tracking-wide uppercase opacity-60">{stage}</p>
      <h1 className="mt-1 text-2xl font-bold">{title}</h1>
      {description ? <p className="mt-3 text-sm opacity-80">{description}</p> : null}
      {values?.length ? (
        <dl className="mt-4 rounded border px-3 py-2 font-mono text-xs">
          {values.map((item) => (
            <div key={item.label} className="flex gap-2">
              <dt className="opacity-60">{item.label}:</dt>
              <dd>{item.value}</dd>
            </div>
          ))}
        </dl>
      ) : null}
    </section>
  )
}
