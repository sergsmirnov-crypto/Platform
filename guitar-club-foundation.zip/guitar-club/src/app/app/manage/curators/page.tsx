import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Карточки кураторов' }

export default function ManageCuratorsPage() {
  return (
    <PagePlaceholder
      title="Карточки кураторов"
      stage="Этап 8"
      description="Профили кураторов и порядок их вывода."
    />
  )
}
