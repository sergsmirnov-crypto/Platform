import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Миграция' }

export default function MigrationPage() {
  return (
    <PagePlaceholder
      title="Миграция"
      stage="Этап 5"
      description="Массовая разметка материалов, перенесённых из Telegram."
    />
  )
}
