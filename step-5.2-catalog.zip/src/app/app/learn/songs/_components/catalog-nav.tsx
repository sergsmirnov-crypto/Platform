import Link from 'next/link'

import { buildCatalogQuery, CATALOG_PRESETS, isPresetActive } from '@/modules/songs'
import type { CatalogFilters } from '@/modules/songs'
import { routes } from '@/shared/routes'
import { cn } from '@/ui'

/**
 * Быстрые подборки и переход по страницам.
 *
 * Оба — ссылки, оба серверные. Подборки отвечают на вопрос, с которым
 * человек приходит на самом деле: не «покажи разборы уровня intermediate
 * в строе DADGAD», а «что мне разобрать сегодня вечером».
 */

export function CatalogPresets({ filters }: { filters: CatalogFilters }) {
  return (
    <div className="mb-6 flex flex-wrap gap-2">
      {CATALOG_PRESETS.map((preset) => {
        const active = isPresetActive(preset, filters)

        // Нажатие на выбранную подборку снимает её — иначе выбравшись
        // из «Для новичка» можно только через «Сбросить всё»
        const next = active ? {} : { ...preset.filters, sort: filters.sort, query: filters.query }

        return (
          <Link
            key={preset.value}
            href={`${routes.app.learn.songs()}${buildCatalogQuery(next as Partial<CatalogFilters>)}`}
            aria-pressed={active}
            className={cn(
              'inline-flex min-h-9 items-center rounded-full border px-4 text-sm transition-colors',
              active
                ? 'border-border-strong bg-surface-hover text-content font-medium'
                : 'border-border text-content-muted hover:border-border-strong',
            )}
          >
            {preset.label}
          </Link>
        )
      })}
    </div>
  )
}

type PaginationProps = {
  filters: CatalogFilters
  page: number
  pageCount: number
}

/**
 * Переход по страницам.
 *
 * Номера показываются только соседние: при сорока страницах полный
 * список номеров занимает больше места, чем сами карточки, и попасть
 * пальцем в нужный невозможно.
 */
export function CatalogPagination({ filters, page, pageCount }: PaginationProps) {
  if (pageCount <= 1) return null

  const numbers = new Set<number>([1, pageCount, page - 1, page, page + 1])
  const visible = [...numbers]
    .filter((value) => value >= 1 && value <= pageCount)
    .sort((a, b) => a - b)

  function href(target: number): string {
    return `${routes.app.learn.songs()}${buildCatalogQuery({ ...filters, page: target })}`
  }

  return (
    <nav className="mt-10 flex flex-wrap items-center justify-center gap-2" aria-label="Страницы">
      {page > 1 ? (
        <Link
          href={href(page - 1)}
          rel="prev"
          className="border-border text-content-muted hover:border-border-strong inline-flex h-11 items-center rounded-full border px-4 text-sm"
        >
          Назад
        </Link>
      ) : null}

      {visible.map((value, index) => (
        <span key={value} className="flex items-center gap-2">
          {index > 0 && value - (visible[index - 1] ?? 0) > 1 ? (
            <span className="text-content-subtle px-1">…</span>
          ) : null}

          <Link
            href={href(value)}
            aria-current={value === page ? 'page' : undefined}
            className={cn(
              'inline-flex h-11 min-w-11 items-center justify-center rounded-full border px-3 text-sm',
              value === page
                ? 'border-accent bg-accent text-accent-content font-medium'
                : 'border-border text-content-muted hover:border-border-strong',
            )}
          >
            {value}
          </Link>
        </span>
      ))}

      {page < pageCount ? (
        <Link
          href={href(page + 1)}
          rel="next"
          className="border-border text-content-muted hover:border-border-strong inline-flex h-11 items-center rounded-full border px-4 text-sm"
        >
          Вперёд
        </Link>
      ) : null}
    </nav>
  )
}
