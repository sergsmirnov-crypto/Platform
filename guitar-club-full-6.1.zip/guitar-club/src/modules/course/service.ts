import 'server-only'

import { isCompleted } from '@/modules/progress'
import type { ContentViewer } from '@/shared/content'
import { errors } from '@/shared/errors'

import { parseLessonContent } from './content'
import { findLessonBySlug, findLessons, findModules, findPrimaryCourse } from './repository'

import type { CourseMap, LessonView, ModuleListItem } from './types'

/**
 * Сборка курса для показа.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПРОГРЕСС ЗАБИРАЕТСЯ ОДНИМ ЗАПРОСОМ НА ВЕСЬ КУРС
 *
 * Курс из сорока уроков не может позволить себе сорок обращений
 * к базе за отметками «пройдено». Все идентификаторы уроков известны
 * сразу после выборки, поэтому прогресс берётся разом и раскладывается
 * по урокам в памяти.
 *
 * Это же объясняет, почему прогресс — отдельный модуль, а не колонка
 * в уроке: отметка принадлежит паре «человек и урок», а не уроку.
 *
 * Само соединение живёт в `repository.ts`: модулю курса разрешены
 * таблицы соседа, но не его сервис. Формула «что считать пройденным»
 * остаётся в модуле прогресса.
 * ─────────────────────────────────────────────────────────────────
 */

/** Карта курса: модули, уроки и отметки о прохождении */
export async function getCourseMap(viewer: ContentViewer): Promise<CourseMap | null> {
  const course = await findPrimaryCourse(viewer.canSeeDrafts)
  if (!course) return null

  const modules = await findModules(course.id, viewer.canSeeDrafts)
  const lessonRows = await findLessons(
    modules.map((module) => module.id),
    viewer.canSeeDrafts,
    viewer.userId,
  )

  const byModule = new Map<string, ModuleListItem['lessons']>()

  for (const lesson of lessonRows) {
    const list = byModule.get(lesson.moduleId) ?? []

    list.push({
      id: lesson.id,
      slug: lesson.slug,
      title: lesson.title,
      summary: lesson.summary,
      estimatedMinutes: lesson.estimatedMinutes,
      hasVideo: lesson.videoAssetId !== null,
      isFreePreview: lesson.isFreePreview,
      isDraft: lesson.status !== 'published',
      // Решение принимает модуль прогресса: «пройдено» — это ручная
      // отметка ИЛИ достаточная доля просмотра, и знать эту формулу
      // курсу незачем
      completed: isCompleted({
        percent: lesson.percent ?? 0,
        completedManually: lesson.completedManually ?? false,
      }),
    })

    byModule.set(lesson.moduleId, list)
  }

  return {
    ...course,
    modules: modules.map((module) => ({
      id: module.id,
      slug: module.slug,
      title: module.title,
      description: module.description,
      isDraft: module.status !== 'published',
      lessons: byModule.get(module.id) ?? [],
    })),
  }
}

/** Страница урока. Содержимое разбирается здесь, дальше идут только блоки */
export async function getLesson(
  viewer: ContentViewer,
  moduleSlug: string,
  lessonSlug: string,
): Promise<LessonView> {
  const row = await findLessonBySlug(moduleSlug, lessonSlug, viewer.canSeeDrafts)
  if (!row) throw errors.notFound('Урок не найден')

  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    summary: row.summary,
    content: parseLessonContent(row.content),
    videoAssetId: row.videoAssetId,
    estimatedMinutes: row.estimatedMinutes,
    isFreePreview: row.isFreePreview,
    isDraft: row.status !== 'published',
    module: { id: row.moduleId, slug: row.moduleSlug, title: row.moduleTitle },
    course: { id: row.courseId, slug: row.courseSlug, title: row.courseTitle },
  }
}
