import 'server-only'

import { can } from '@/modules/access'

import { findCatalogFacets, findCatalogPage, findSongBySlug } from './repository'

import type { CatalogFilters } from './catalog-filters'
import type { CatalogFacets } from './repository'
import type { CatalogPage, SongView } from './types'

/**
 * Разборы: что показывать и кому.
 *
 * Между страницей и запросами к базе стоит ровно ради одного решения —
 * видит ли этот человек черновики. Решение принимается здесь, один раз
 * и по правам, а не в каждом обращении к каталогу.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПОЧЕМУ ЭТО НЕ ПАРАМЕТР СТРАНИЦЫ
 *
 * Соблазнительно передавать «показывать черновики» сверху: страница
 * знает, кто её открыл. Но тогда правило размазывается по всем местам,
 * где разборы читают, и достаточно один раз забыть — черновик уедет
 * участникам. Здесь забыть нельзя: другого способа получить разборы нет.
 * ─────────────────────────────────────────────────────────────────
 *
 * Проверка подписки в этом слое отсутствует намеренно. Список разборов
 * открыт и тем, у кого подписка закончилась: они видят каталог
 * и описания, но не видео и не табы. Закрывается доступ к самому
 * содержимому — при выдаче ссылки на видео (шаг 5.4).
 */

/** Может ли человек видеть неопубликованное */
async function canSeeDrafts(userId: string): Promise<boolean> {
  return can(userId, 'songs.view_drafts')
}

export async function getCatalogPage(
  userId: string,
  filters: CatalogFilters,
): Promise<CatalogPage> {
  return findCatalogPage({ ...filters, includeDrafts: await canSeeDrafts(userId) })
}

/** Значения для фильтров: только те, что реально встречаются */
export async function getCatalogFacets(userId: string): Promise<CatalogFacets> {
  return findCatalogFacets(await canSeeDrafts(userId))
}

export async function getSongBySlug(userId: string, slug: string): Promise<SongView | null> {
  return findSongBySlug(slug, await canSeeDrafts(userId))
}

/**
 * Каталог для того, кто не вошёл.
 *
 * Понадобится публичной витрине, если она появится (PRD v0.1 §15, вопрос 9).
 * Отдельная функция, а не «userId может быть пустым»: пустой идентификатор
 * в проверке прав — это способ однажды случайно показать черновики
 * тому, у кого прав нет вовсе.
 */
export async function getPublicCatalogPage(filters: CatalogFilters): Promise<CatalogPage> {
  return findCatalogPage({ ...filters, includeDrafts: false })
}
