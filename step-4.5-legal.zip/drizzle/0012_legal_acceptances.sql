-- Согласия с правовыми документами (шаг 4.5)
--
-- Запись на каждую редакцию документа, а не флаг «согласен» в `users`.
-- Флаг отвечал бы на вопрос «согласен ли», а нужен ответ на вопрос
-- «с чем именно согласен»: оферта будет меняться, и после первой правки
-- дата в такой колонке ничего не доказывает — неизвестно, какой текст
-- человек видел на экране.
--
-- Строки только добавляются: это журнал, а не состояние. Уникальный
-- индекс гарантирует, что повторное нажатие кнопки не создаст второго
-- согласия с той же редакцией.
--
-- Удаление вместе с участником: согласие имеет смысл только как согласие
-- конкретного человека с конкретным договором. Документы об оплате,
-- которые надо хранить пять лет, лежат отдельно.
--
-- В перечислении только `offer` и `privacy`: с контактами не соглашаются,
-- и общий список всех документов пропустил бы это значение молча.
--
-- Сами тексты в базе не хранятся — они в коде, с номером редакции
-- и контрольной суммой (ADR-0023).

CREATE TYPE "public"."legal_document" AS ENUM('offer', 'privacy');--> statement-breakpoint
CREATE TABLE "legal_acceptances" (
	"id" uuid PRIMARY KEY NOT NULL,
	"user_id" uuid NOT NULL,
	"document" "legal_document" NOT NULL,
	"version" integer NOT NULL,
	"accepted_at" timestamp with time zone DEFAULT now() NOT NULL,
	"ip_hash" text,
	"user_agent" text
);
--> statement-breakpoint
ALTER TABLE "legal_acceptances" ADD CONSTRAINT "legal_acceptances_user_id_users_id_fk" FOREIGN KEY ("user_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE UNIQUE INDEX "legal_acceptances_unique_idx" ON "legal_acceptances" USING btree ("user_id","document","version");