/**
 * Тексты раздела «Курс».
 *
 * Рядом с модулем, а не в компонентах: поправить формулировку по просьбе
 * владельца продукта — значит открыть один файл, а не искать строку
 * по всему проекту.
 */
export const courseStrings = {
  title: 'Курс',
  description: 'Последовательный путь от первого аккорда до своей песни',

  map: {
    empty: 'Курс ещё готовится',
    emptyHint: 'Первые модули появятся, когда кураторы их наполнят',
    progress: (percent: number) => `${percent}% пройдено`,
    modulePosition: (current: number, total: number) => `Модуль ${current} из ${total}`,
    remaining: (minutes: number) => `осталось около ${minutes} мин`,
    lessonsCount: (completed: number, total: number) => `${completed} из ${total}`,
    draft: 'Черновик',
    freePreview: 'Открыт всем',
    emptyModule: 'Уроки этого модуля ещё готовятся',
    finished: 'Курс пройден целиком',
  },

  blocks: {
    tip: 'Совет',
    warning: 'Осторожно',
    chords: 'Аккорды',
  },

  lesson: {
    number: (current: number, total: number) => `Урок ${current} из ${total}`,
    previous: 'Предыдущий',
    next: 'Следующий',
    complete: 'Урок пройден',
    completed: 'Пройден',
    undoComplete: 'Снять отметку',
    duration: (minutes: number) => `${minutes} мин`,
    relatedSong: 'Разбор к этому уроку',
    content: 'Конспект',
    materials: 'Материалы урока',
    noVideo: 'Видео к этому уроку нет',
    noVideoHint: 'Возможно, весь урок в конспекте ниже',
    videoLocked: 'Видео доступно по подписке',
    lockedHint: 'Структура урока и конспект остаются открытыми',
    renew: 'Продлить подписку',
    backToCourse: 'К карте курса',
    draft: 'Черновик — участники его не видят',
  },

  errors: {
    notFound: 'Урок не найден',
  },
} as const
