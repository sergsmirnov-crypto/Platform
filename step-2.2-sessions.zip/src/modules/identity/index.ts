/**
 * Публичный вход в модуль «Личность».
 *
 * Модуль отвечает на вопрос «кто передо мной». На вопрос «что ему можно»
 * отвечает модуль `access`, на вопрос «оплачено ли» — `subscription`.
 *
 * Остальные модули и страницы работают только с тем, что перечислено здесь.
 */
export { getSession, requireSession } from './current-user'
export { devSignIn, signOut, signOutAndRedirect } from './actions'
export { isDevAuthAvailable } from './dev-auth'
export {
  cleanupSessions,
  endAllSessions,
  endDevice,
  endSession,
  listDevices,
  startSession,
} from './service'
export { findAllUsersForDevelopment, findUserById } from './repository'
export { identityStrings } from './strings'

export type { RequestOrigin, SessionContext, SessionDevice, SessionUser } from './types'
