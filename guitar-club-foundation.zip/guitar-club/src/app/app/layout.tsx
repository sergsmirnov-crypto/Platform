import { TemporaryNav } from './_components/temporary-nav'

/**
 * Разметка закрытой зоны.
 *
 * Сюда на Этапе 2 придёт проверка сессии и подписки, а на Этапе 3 —
 * сайдбар, шапка и хлебные крошки. Сейчас это только контейнер
 * и временная навигация для проверки каркаса.
 *
 * Почему проверка доступа будет именно здесь, а не в middleware:
 * разметка выполняется на сервере и имеет доступ к базе данных,
 * поэтому может проверить, что сессия действительно живая (ADR-0003).
 */
export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh">
      <TemporaryNav />
      {children}
    </div>
  )
}
