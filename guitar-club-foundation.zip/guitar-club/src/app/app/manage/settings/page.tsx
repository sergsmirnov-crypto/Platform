import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Настройки платформы' }

export default function PlatformSettingsPage() {
  return (
    <PagePlaceholder
      title="Настройки платформы"
      stage="Этап 9"
      description="Тексты онбординга, ссылки на чаты, фиче-флаги."
    />
  )
}
