import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Подписка закончилась' }

export default function SubscriptionExpiredPage() {
  return (
    <PagePlaceholder
      title="Подписка закончилась"
      stage="Этап 2"
      description="Сохранённый прогресс, что нового в клубе и кнопка продления."
    />
  )
}
