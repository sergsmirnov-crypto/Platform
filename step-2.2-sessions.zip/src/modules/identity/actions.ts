'use server'

import { redirect } from 'next/navigation'
import { z } from 'zod'

import { errors } from '@/shared/errors'
import { getLogger } from '@/shared/logger'
import { routes } from '@/shared/routes'
import { enforceRateLimit } from '@/shared/security/rate-limit'
import { defineAction } from '@/shared/server'

import { clearSessionCookie, getRequestOrigin, setSessionCookie } from './cookie'
import { getSession } from './current-user'
import { isDevAuthAvailable } from './dev-auth'
import { findUserById } from './repository'
import { endSession, startSession } from './service'
import { identityStrings } from './strings'

/**
 * Действия входа и выхода.
 *
 * Настоящий вход через Telegram появится на шаге 2.3. Здесь пока служебный
 * вход для разработки и общий выход — этого достаточно, чтобы проверить,
 * что сессии работают.
 */

/**
 * Вход под существующим участником без обращения к Telegram.
 *
 * Нужен по практической причине: виджет входа Telegram работает только
 * на домене, зарегистрированном у бота, и на `localhost` не запускается.
 * Без этой двери разработку всех следующих этапов пришлось бы вести
 * на живом сервере.
 *
 * Защита простая и надёжная: в производственной сборке `NODE_ENV`
 * равен `production`, и действие отказывает сразу, не заглядывая в базу.
 */
export const devSignIn = defineAction({
  name: 'identity.devSignIn',
  input: z.object({ userId: z.uuid() }),
  handler: async ({ userId }) => {
    if (!isDevAuthAvailable()) {
      getLogger().warn('попытка служебного входа вне режима разработки')
      throw errors.forbidden(identityStrings.devSignIn.unavailable)
    }

    const user = await findUserById(userId)
    if (!user) {
      throw errors.notFound(identityStrings.errors.userNotFound)
    }

    const origin = await getRequestOrigin()
    const { token, expiresAt } = await startSession(user.id, origin)
    await setSessionCookie(token, expiresAt)

    return { userId: user.id }
  },
})

/**
 * Выход.
 *
 * Сессия закрывается в базе, а не только удаляется cookie: иначе
 * скопированный ранее ключ продолжал бы работать.
 */
export const signOut = defineAction({
  name: 'identity.signOut',
  handler: async () => {
    const session = await getSession()

    if (session) {
      await endSession(session.sessionId)
    }

    await clearSessionCookie()

    return { ok: true }
  },
})

/**
 * Выход с перенаправлением на лендинг — для кнопки в интерфейсе.
 *
 * Отдельное действие, потому что `redirect` внутри `defineAction`
 * работать не может: он бросает специальное исключение, которое обёртка
 * приняла бы за ошибку.
 */
export async function signOutAndRedirect(): Promise<void> {
  const session = await getSession()

  if (session) {
    await endSession(session.sessionId)
  }

  await clearSessionCookie()

  redirect(routes.home())
}

/**
 * Ограничение частоты попыток входа.
 *
 * Вызывается перед проверкой данных, чтобы перебор упирался в лимит
 * до обращения к базе. Понадобится на шаге 2.3; здесь объявлено рядом
 * с остальными действиями входа, чтобы не разъезжалось по проекту.
 */
export async function enforceLoginRateLimit(): Promise<void> {
  const origin = await getRequestOrigin()

  enforceRateLimit({
    action: 'login',
    subject: origin.ip ?? 'unknown',
    limit: 10,
    windowSeconds: 300,
  })
}
