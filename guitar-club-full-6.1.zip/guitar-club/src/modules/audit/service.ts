import 'server-only'

import { getLogger } from '@/shared/logger'

import { insertAuditEntry } from './repository'

/**
 * Журнал действий.
 *
 * Практическая польза не в безопасности, а в разборе полётов: «куда делся
 * разбор Nothing Else Matters» и «почему куратор всё утро не видел
 * черновик» решаются за десять секунд вместо часа переписки (PRD v0.3 §6).
 *
 * Экран журнала появится на Этапе 9. Сейчас важна сама запись: если начать
 * писать не с первого управляющего действия, а «когда дойдут руки»,
 * в журнале навсегда останется дыра именно за тот период, который потом
 * понадобится восстановить.
 */

export type AuditEvent = {
  /** Кто сделал. `null` — действие выполнила система, без участия человека */
  actorId: string | null
  /** Что сделал. Брать из `AUDIT_ACTIONS`, а не писать строкой */
  action: string
  /** Над чем: 'song', 'user'. Пусто, если действие ни к чему не привязано */
  entityType?: string | null
  entityId?: string | null
  /** Что именно изменилось: было и стало */
  diff?: Record<string, unknown> | null
  /** Хеш адреса, откуда пришёл запрос. Сам адрес не храним — это персданные */
  ipHash?: string | null
}

/**
 * Записывает действие в журнал.
 *
 * **Никогда не роняет вызывающий код.** Журнал — вспомогательная вещь:
 * если запись не удалась, куратор всё равно должен опубликовать разбор.
 * Обратный порядок («не записали — не сделали») означал бы, что временная
 * проблема с базой останавливает работу всего клуба ради строчки истории.
 * Сбой записи уходит в журнал приложения, где его увидит разработчик.
 */
export async function recordAudit(event: AuditEvent): Promise<void> {
  try {
    await insertAuditEntry({
      actorId: event.actorId,
      action: event.action,
      entityType: event.entityType ?? null,
      entityId: event.entityId ?? null,
      diff: event.diff ?? null,
      ipHash: event.ipHash ?? null,
    })
  } catch (error) {
    getLogger().error(
      { err: error, auditAction: event.action },
      'не удалось записать действие в журнал',
    )
  }
}
