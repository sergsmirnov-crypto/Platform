/**
 * Тексты раздела «Эфиры».
 *
 * Рядом с модулем, а не в компонентах: поправить формулировку по просьбе
 * владельца продукта — значит открыть один файл.
 */

import { plural } from '@/shared/utils/plural'

export const streamStrings = {
  title: 'Эфиры',
  description: 'Живые разборы и ответы на вопросы. Записи остаются в архиве',

  list: {
    upcoming: 'Ближайшие',
    archive: 'Архив записей',
    empty: 'Записей пока нет',
    emptyHint: 'Первые появятся после ближайшего эфира',
    emptyUpcoming: 'Ближайшие эфиры пока не назначены',
    allUpcoming: 'Все ближайшие',
    searchPlaceholder: 'Тема эфира или куратор',
    found: (total: number) => `Найдено: ${total}`,
    notFound: (query: string) => `По запросу «${query}» ничего не нашлось`,
    notFoundHint: 'Попробуйте одно слово из темы или снимите отбор по куратору',
    reset: 'Показать все записи',
    allCurators: 'Все кураторы',
    liveNow: 'Эфир идёт прямо сейчас',
    upcomingHint: 'Ближайшие эфиры и то, что идёт прямо сейчас',
    archiveHint: 'Записи прошедших эфиров. Оглавление есть у каждой',
    watched: (percent: number) => `Просмотрено ${percent}%`,
    chapterCount: (total: number) => `${total} ${plural(total, 'пункт', 'пункта', 'пунктов')} в оглавлении`, // prettier-ignore
  },

  phase: {
    upcoming: 'Скоро',
    live: 'Идёт сейчас',
    finished: 'Запись готовится',
    recorded: 'Запись',
    cancelled: 'Отменён',
  },

  page: {
    join: 'Присоединиться',
    calendar: 'Добавить в календарь',
    calendarHint: 'Эфир попадёт в календарь телефона — напоминание поставьте себе сами',
    localTime: (time: string) => `у вас — ${time}`,
    timezone: 'МСК',
    joinClosed: 'Кнопка появится за 15 минут до начала',
    songsHint: 'Разборы этих песен есть в библиотеке',
    joinHint: 'Откроется в Telegram или Zoom',
    chapters: 'О чём говорили',
    chaptersHint: 'Нажмите на пункт, чтобы перейти к нужному месту',
    songs: 'Разобранные песни',
    materials: 'Материалы эфира',
    curator: 'Ведёт',
    noVideo: 'Записи пока нет',
    noVideoHint: 'Куратор выложит её в ближайшие дни',
    videoLocked: 'Запись доступна по подписке',
    lockedHint: 'Описание и оглавление остаются открытыми',
    renew: 'Продлить подписку',
    cancelled: 'Эфир отменён',
    backToList: 'Ко всем эфирам',
    inStreams: 'Эту песню разбирали в эфирах',
    draft: 'Черновик — участники его не видят',
  },

  errors: {
    notFound: 'Эфир не найден',
  },

  dashboard: {
    title: 'Ближайший эфир',
    all: 'Все эфиры',
  },
} as const
