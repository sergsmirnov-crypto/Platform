/**
 * Таймкоды: «2:14» ↔ 134 секунды.
 *
 * Чистые функции, поэтому лежат в модуле, а не рядом с формой. Ими будет
 * пользоваться не только редактор: экран массовой разметки при переносе
 * из Telegram разбирает те же значения, вытащенные из подписей к видео.
 *
 * Это место редактора, где ошибка тише всего и дороже всего: неверно
 * распознанное «2:14» отправит участника не в ту часть разбора,
 * и жалоба придёт не от куратора, а от участника через неделю.
 */

/**
 * «2:14» → 134 секунды.
 *
 * Принимает и «134», и «2:14», и «1:02:30»: куратор переписывает то,
 * что видит в плеере, а видит он там разное в зависимости от длины ролика.
 * Пустая строка означает «таймкод не указан», а не ноль.
 */
export function parseTimecode(value: string): number | null {
  const trimmed = value.trim()
  if (!trimmed) return null

  const parts = trimmed.split(':').map((part) => Number.parseInt(part, 10))
  if (parts.some((part) => Number.isNaN(part))) return null

  return parts.reduce((total, part) => total * 60 + part, 0)
}

/** 134 → «2:14». Обратное превращение для показа в поле */
export function formatTimecode(seconds: number | null): string {
  if (seconds === null) return ''

  const hours = Math.floor(seconds / 3600)
  const minutes = Math.floor((seconds % 3600) / 60)
  const rest = seconds % 60
  const padded = String(rest).padStart(2, '0')

  return hours > 0
    ? `${hours}:${String(minutes).padStart(2, '0')}:${padded}`
    : `${minutes}:${padded}`
}
