import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Избранное' }

export default function FavoritesPage() {
  return (
    <PagePlaceholder
      title="Избранное"
      stage="Этап 10"
      description="Отложенные разборы, уроки и эфиры."
    />
  )
}
