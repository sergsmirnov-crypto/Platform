import { SessionIndicator } from './_components/session-indicator'
import { SubscriptionBadge } from './_components/subscription-badge'
import { TemporaryNav } from './_components/temporary-nav'

/**
 * Разметка закрытой зоны.
 *
 * На Этапе 2 сюда придёт проверка сессии и подписки, а на Этапе 3 —
 * сайдбар, шапка и хлебные крошки. Сейчас это контейнер, временная
 * навигация и указатель текущего человека.
 *
 * Почему проверка доступа будет именно здесь, а не в middleware:
 * разметка выполняется на сервере и имеет доступ к базе данных,
 * поэтому может проверить, что сессия действительно живая (ADR-0003).
 */
export default function AppLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-dvh">
      <div className="flex flex-wrap items-center justify-end gap-3 border-b px-6 py-2">
        <SubscriptionBadge />
        <SessionIndicator />
      </div>
      <TemporaryNav />
      {children}
    </div>
  )
}
