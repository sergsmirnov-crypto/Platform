'use client'

import KinescopePlayer from '@kinescope/player-iframe-api-loader/react/KinescopePlayer'
import { useCallback, useEffect, useRef, useState } from 'react'

import type { PlaybackTicket } from '@/modules/media'

/**
 * Плеер разбора.
 *
 * ─────────────────────────────────────────────────────────────────
 * ЕДИНСТВЕННЫЙ КОМПОНЕНТ СТРАНИЦЫ, РАБОТАЮЩИЙ В БРАУЗЕРЕ
 *
 * Всё остальное на странице песни собирается на сервере. Плееру браузер
 * нужен по существу: переход к части разбора, скорость воспроизведения
 * и полноэкранный режим невозможно сделать ссылками.
 *
 * Компонент намеренно ничего не знает про Kinescope, кроме библиотеки
 * плеера: адрес, водяной знак и оглавление приходят готовыми, собранными
 * на сервере. Смена хостинга заменит один файл в `shared/video`,
 * а не этот компонент.
 * ─────────────────────────────────────────────────────────────────
 *
 * **Про водяной знак.** Он задаётся настройками плеера, а не адресом,
 * поэтому убрать его правкой строки в браузере нельзя. Режим `random` —
 * текст всплывает в случайных местах экрана: перекрыть его при записи
 * не выйдет, а обрезать кадр — значит обрезать и сам разбор.
 */

type VideoPlayerProps = {
  ticket: PlaybackTicket
  /** Секунда, к которой нужно перейти. Меняется при выборе части разбора */
  seekTo?: number | null
  title?: string
}

/** Скорости для разбора: медленнее — чтобы успеть, быстрее — чтобы повторить */
const RATES = [0.5, 0.75, 1, 1.25, 1.5] as const

export function VideoPlayer({ ticket, seekTo, title }: VideoPlayerProps) {
  const playerRef = useRef<Kinescope.IframePlayer.Player | null>(null)
  const [rate, setRate] = useState(1)

  const handleCreate = useCallback((player: Kinescope.IframePlayer.Player) => {
    playerRef.current = player
  }, [])

  const handleDestroy = useCallback(() => {
    playerRef.current = null
  }, [])

  // Переход к части разбора. Плеер живёт дольше выбранной части, поэтому
  // перемотка — это побочный эффект, а не пересоздание плеера: пересоздание
  // обрывало бы загрузку и заново показывало заставку
  useEffect(() => {
    if (seekTo === null || seekTo === undefined) return

    void playerRef.current?.seekTo(seekTo)
  }, [seekTo])

  const changeRate = useCallback((value: number) => {
    setRate(value)
    void playerRef.current?.setPlaybackRate(value)
  }, [])

  return (
    <div className="space-y-3">
      <div className="bg-surface-sunken overflow-hidden rounded-lg">
        <KinescopePlayer
          className="aspect-video w-full"
          onCreate={handleCreate}
          onDestroy={handleDestroy}
          options={{
            url: ticket.url,
            size: { width: '100%', height: '100%' },
            behavior: {
              playsInline: true,
              autoPause: true,
              // Позицию просмотра платформа будет помнить сама, на сервере
              // (Этап 10): своя память переживает смену устройства,
              // а память браузера — нет
              localStorage: { time: false },
            },
            ui: {
              language: 'ru',
              playbackRateButton: true,
              watermark: {
                text: ticket.watermark,
                mode: 'random',
              },
            },
            playlist: [
              {
                ...(title ? { title } : {}),
                ...(ticket.chapters.length > 0 ? { chapters: ticket.chapters } : {}),
              },
            ],
          }}
        />
      </div>

      {/* Скорость вынесена наружу плеера: при разборе её меняют по десять
          раз за занятие, и лезть за ней в меню настроек — мучение */}
      <div className="flex items-center gap-2">
        <span className="text-content-subtle text-xs tracking-wide uppercase">Скорость</span>
        {RATES.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => changeRate(value)}
            aria-pressed={rate === value}
            className={
              rate === value
                ? 'border-accent bg-accent text-accent-content inline-flex h-9 items-center rounded-full border px-3 text-sm font-medium'
                : 'border-border text-content-muted hover:border-border-strong inline-flex h-9 items-center rounded-full border px-3 text-sm'
            }
          >
            {value}×
          </button>
        ))}
      </div>
    </div>
  )
}
