/**
 * Публичный вход в модуль журнала действий.
 *
 * Отвечает на вопрос «кто, что и когда сделал». Права проверяет модуль
 * `access`, кто человек — `identity`: журнал только фиксирует факт.
 */
export { recordAudit } from './service'
export type { AuditEvent } from './service'

export { AUDIT_ACTIONS } from './actions.catalog'
export type { AuditAction } from './actions.catalog'
