/**
 * Публичный вход в модуль разборов.
 *
 * Здесь перечислено только то, что работает в любом окружении. Всё
 * серверное — сервис и запросы — импортируется явным путём:
 *
 *     import { getCatalogPage } from '@/modules/songs/service'
 *
 * Причина та же, что у остальных модулей: публичный вход тянут в том
 * числе браузерные компоненты, и серверный код через него протаскивать
 * нельзя.
 */
export {
  compareLevels,
  estimateLabel,
  formatDuration,
  isLevel,
  isPubliclyVisible,
  isTuning,
  LEVELS,
  LEVEL_VALUES,
  levelLabel,
  resolveSectionPlayback,
  sectionDuration,
  SECTION_TEMPLATES,
  sectionsFromTemplate,
  songSlug,
  totalDuration,
  TUNINGS,
  TUNING_VALUES,
  tuningLabel,
  uniqueSlug,
} from './domain'
export type { Level, PlaybackSource, SectionTemplate, Tuning } from './domain'

export {
  buildCatalogQuery,
  CATALOG_PRESETS,
  DEFAULT_SORT,
  hasActiveFilters,
  isPresetActive,
  pageCount,
  pageOffset,
  parseCatalogFilters,
  SORT_OPTIONS,
} from './catalog-filters'
export type { CatalogFilters, CatalogPreset, RawSearchParams, SortOption } from './catalog-filters'

export {
  groupByLevel,
  hasVariantChoice,
  nearestLevel,
  selectArrangement,
  variantLabel,
} from './arrangement-selection'
export type {
  LevelGroup,
  SelectableArrangement,
  Selection,
  SelectionRequest,
} from './arrangement-selection'

export {
  arrangementInputSchema,
  reorderSchema,
  sectionInputSchema,
  songInputSchema,
} from './editor-schema'
export type { ArrangementInput, SectionInput, SongInput } from './editor-schema'

export { canPublish, findPublicationBlockers, nextStatus } from './publication'
export type { PublicationBlocker } from './publication'

export { formatTimecode, parseTimecode } from './timecode'

export { songStrings } from './strings'

export type {
  ArrangementView,
  CatalogPage,
  MaterialView,
  SectionView,
  SimilarSong,
  SongCard,
  SongView,
  TagView,
} from './types'
