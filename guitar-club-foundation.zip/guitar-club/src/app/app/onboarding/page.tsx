import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Знакомство' }

export default function OnboardingPage() {
  return (
    <PagePlaceholder
      title="Знакомство"
      stage="Этап 4"
      description="Мастер первого входа: четыре быстрых вопроса и первый разбор."
    />
  )
}
