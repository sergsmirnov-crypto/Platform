import { PagePlaceholder } from '../_components/page-placeholder'

export const metadata = { title: 'Обучение' }

export default function LearnHubPage() {
  return (
    <PagePlaceholder title="Обучение" stage="Этап 3" description="Общий вход в разборы и курс." />
  )
}
