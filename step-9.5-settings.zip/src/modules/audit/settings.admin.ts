import 'server-only'

import { errors } from '@/shared/errors'
import { getLogger } from '@/shared/logger'

import { AUDIT_ACTIONS } from './actions.catalog'
import { recordAudit } from './service'
import { SETTING_DEFAULTS } from './settings.catalog'
import { SETTING_SCHEMAS, isEditableSetting } from './settings.schema'
import { getSetting, setSetting } from './settings.service'

import type { ClubAbout, TelegramChatLink } from './settings.catalog'
import type { EditableSettingKey } from './settings.schema'

/**
 * Правка настроек платформы.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПОЧЕМУ ПРАВО ПРОВЕРЯЕТСЯ НЕ ЗДЕСЬ, А В ДЕЙСТВИИ
 *
 * Единственное отступление от общего правила во всём проекте, и оно
 * вынужденное: модуль `access` уже импортирует `audit`, чтобы писать
 * выдачу прав в журнал. Обратный импорт замкнул бы два модуля в кольцо,
 * а кольцо при загрузке даёт пустые ссылки в самых неожиданных местах.
 *
 * Поэтому `requirePermission('settings.edit')` стоит в серверном
 * действии — единственной точке входа снаружи. Проверка от этого
 * не становится слабее (действие тоже выполняется на сервере), но
 * становится менее заметной, и это плохо.
 *
 * Правильное решение — вынести настройки из `audit` в собственный
 * модуль: журнал действий и тексты страницы «О клубе» вообще ничем
 * не связаны, кроме истории. Это переезд файлов и правка четырёх мест
 * чтения, и делать его надо отдельным шагом.
 * ─────────────────────────────────────────────────────────────────
 */

export type EditableSettings = {
  renewUrl: string
  chats: TelegramChatLink[]
  about: ClubAbout
}

export async function getEditableSettings(): Promise<EditableSettings> {
  const [renewUrl, chats, about] = await Promise.all([
    getSetting<string>('subscription.renew_url'),
    getSetting<TelegramChatLink[]>('telegram.chats'),
    getSetting<ClubAbout>('club.about'),
  ])

  return { renewUrl, chats, about }
}

/**
 * Записывает настройку, проверив значение.
 *
 * Ключ проверяется по списку: править из интерфейса можно только
 * перечисленное. Иначе произвольная строка в запросе позволила бы
 * записать что угодно под любым ключом — включая те, которые появятся
 * в будущем и не рассчитаны на правку человеком.
 */
export async function updateSetting(
  actorId: string,
  key: string,
  value: unknown,
  context: { ipHash?: string | null } = {},
): Promise<void> {
  if (!isEditableSetting(key)) {
    throw errors.notFound('Такой настройки нет')
  }

  const parsed = SETTING_SCHEMAS[key].safeParse(value)

  if (!parsed.success) {
    const issue = parsed.error.issues[0]

    throw errors.validation(
      { [issue?.path.join('.') || 'value']: issue?.message ?? 'Значение не подходит' },
      issue?.message ?? 'Значение не подходит',
    )
  }

  await setSetting(key, parsed.data, actorId)

  await recordAudit({
    actorId,
    action: AUDIT_ACTIONS.settingsUpdate,
    entityType: 'setting',
    entityId: key,
    ipHash: context.ipHash ?? null,
  })

  getLogger().info({ actorId, settingKey: key }, 'настройка платформы изменена')
}

/**
 * Возвращает настройку к исходному значению.
 *
 * Нужно ровно тогда, когда текст правили-правили и испортили: вернуть
 * заводской вариант проще, чем вспоминать, как было.
 */
export async function resetSetting(
  actorId: string,
  key: EditableSettingKey,
  context: { ipHash?: string | null } = {},
): Promise<void> {
  await updateSetting(actorId, key, SETTING_DEFAULTS[key], context)
}
