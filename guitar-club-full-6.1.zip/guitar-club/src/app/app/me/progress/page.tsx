import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Мой прогресс' }

export default function ProgressPage() {
  return (
    <PagePlaceholder
      title="Мой прогресс"
      stage="Этап 10"
      description="Пройденные уроки, разобранные песни, календарь активности."
    />
  )
}
