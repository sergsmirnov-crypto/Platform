/**
 * Ключи действий, попадающих в журнал.
 *
 * Собраны в одном месте по той же причине, что и права: строка `'preview.enter'`,
 * написанная руками в трёх файлах, рано или поздно превратится в
 * `'preview_enter'` в четвёртом — и запись потеряется при поиске.
 *
 * Правило именования: `объект.действие` в единственном числе.
 * Список пополняется по мере появления управляющих действий.
 */
export const AUDIT_ACTIONS = {
  /** Куратор включил режим «смотреть как участник» */
  previewEnter: 'preview.enter',
  /** Куратор вернулся к управлению */
  previewExit: 'preview.exit',
  /** Участник удалил свой аккаунт */
  accountDelete: 'account.delete',
} as const

export type AuditAction = (typeof AUDIT_ACTIONS)[keyof typeof AUDIT_ACTIONS]
