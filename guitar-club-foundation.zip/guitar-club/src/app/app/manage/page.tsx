import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Управление' }

export default function ManageHubPage() {
  return (
    <PagePlaceholder
      title="Управление"
      stage="Этап 5"
      description="Что опубликовано, что в черновиках, что требует внимания."
    />
  )
}
