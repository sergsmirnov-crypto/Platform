'use server'

import { revalidatePath } from 'next/cache'
import { z } from 'zod'

import { authorizeAttachmentTarget, requireAttachmentTarget } from '@/app/_lib/attachment-access'
import { AUDIT_ACTIONS, recordAudit } from '@/modules/audit'
import { getSession } from '@/modules/identity/current-user'
import { externalMaterialSchema, materialTitleSchema } from '@/modules/media'
import {
  addExternalMaterial,
  findMaterialOwner,
  moveMaterial,
  removeMaterial,
  renameMaterial,
  setMaterialDownloadable,
} from '@/modules/media/materials-service'
import { errors } from '@/shared/errors'
import { routes } from '@/shared/routes'
import { defineAction } from '@/shared/server'

/**
 * Управление материалами разбора.
 *
 * Байты сюда не попадают: их принимает обработчик адреса
 * `/api/media/upload`. Здесь всё, что делается с уже загруженным, —
 * подпись, порядок, разрешение скачивать, удаление и добавление ссылки.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПОРЯДОК ПРОВЕРОК ОДИНАКОВ ВЕЗДЕ
 *
 *   1. кто это           → сессия
 *   2. к чему привязано  → модуль медиа
 *   3. можно ли ему      → право править ЭТОТ объект
 *   4. изменение
 *
 * Шаг 2 обязателен и не может быть пропущен: идентификатор привязки
 * приходит из браузера, и без него мы бы проверяли право на объект,
 * который прислал сам проверяемый.
 * ─────────────────────────────────────────────────────────────────
 */

async function actor(): Promise<string> {
  const session = await getSession()
  if (!session) throw errors.unauthorized()

  return session.user.id
}

/**
 * Сброс кэша.
 *
 * Материал виден в двух местах: в редакторе и на странице песни.
 * Адрес страницы приходит от вызывающего — по идентификатору привязки
 * его пришлось бы искать отдельным запросом ради того, что интерфейс
 * и так знает.
 */
function revalidateMaterials(songSlug: string | null): void {
  revalidatePath(routes.app.manage.songs())
  if (songSlug) revalidatePath(routes.app.learn.song(songSlug))
}

/**
 * Общая часть всех действий: найти привязку и проверить право на объект.
 *
 * Вынесено, потому что повторяется пять раз, а пропущенная проверка
 * в одном из пяти мест не видна при чтении кода.
 */
async function requireOwnedMaterial(attachmentId: string) {
  const actorId = await actor()
  const attachment = await findMaterialOwner(attachmentId)
  const entityType = requireAttachmentTarget(attachment.entityType)

  await authorizeAttachmentTarget(actorId, entityType, attachment.entityId)

  return { actorId, attachment }
}

const withSlug = { songSlug: z.string().nullable().default(null) }

export const renameMaterialAction = defineAction({
  name: 'media.material.rename',
  input: z.object({
    attachmentId: z.uuid(),
    title: materialTitleSchema,
    ...withSlug,
  }),
  handler: async ({ attachmentId, title, songSlug }) => {
    await requireOwnedMaterial(attachmentId)
    await renameMaterial(attachmentId, title)
    revalidateMaterials(songSlug)

    return { title }
  },
})

export const moveMaterialAction = defineAction({
  name: 'media.material.move',
  input: z.object({
    attachmentId: z.uuid(),
    direction: z.enum(['up', 'down']),
    ...withSlug,
  }),
  handler: async ({ attachmentId, direction, songSlug }) => {
    const { attachment } = await requireOwnedMaterial(attachmentId)
    await moveMaterial(attachment, direction)
    revalidateMaterials(songSlug)

    return { moved: true }
  },
})

export const setMaterialDownloadableAction = defineAction({
  name: 'media.material.downloadable',
  input: z.object({
    attachmentId: z.uuid(),
    isDownloadable: z.boolean(),
    ...withSlug,
  }),
  handler: async ({ attachmentId, isDownloadable, songSlug }) => {
    const { attachment } = await requireOwnedMaterial(attachmentId)
    await setMaterialDownloadable(attachment, isDownloadable)
    revalidateMaterials(songSlug)

    return { isDownloadable }
  },
})

export const deleteMaterialAction = defineAction({
  name: 'media.material.delete',
  input: z.object({ attachmentId: z.uuid(), ...withSlug }),
  handler: async ({ attachmentId, songSlug }) => {
    const { actorId, attachment } = await requireOwnedMaterial(attachmentId)

    await removeMaterial(attachment)
    await recordAudit({
      actorId,
      action: AUDIT_ACTIONS.materialDelete,
      entityType: attachment.entityType,
      entityId: attachment.entityId,
      diff: { mediaAssetId: attachment.mediaAssetId },
    })

    revalidateMaterials(songSlug)

    return { deleted: true }
  },
})

export const addExternalMaterialAction = defineAction({
  name: 'media.material.external',
  input: z.object({
    entityType: z.string(),
    entityId: z.uuid(),
    values: externalMaterialSchema,
    ...withSlug,
  }),
  handler: async ({ entityType, entityId, values, songSlug }) => {
    const actorId = await actor()
    const target = requireAttachmentTarget(entityType)

    // Здесь тоже нужно право загружать: ссылка появляется в том же
    // списке материалов и для участника неотличима от файла
    await authorizeAttachmentTarget(actorId, target, entityId, { requireUpload: true })

    const attachmentId = await addExternalMaterial({
      entityType: target,
      entityId,
      values,
      uploadedBy: actorId,
    })

    revalidateMaterials(songSlug)

    return { attachmentId }
  },
})
