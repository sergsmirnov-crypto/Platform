import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

type Props = { params: Promise<{ module: string }> }

export const metadata = { title: 'Модуль курса' }

export default async function CourseModulePage({ params }: Props) {
  const { module } = await params

  return (
    <PagePlaceholder
      title="Модуль курса"
      stage="Этап 6"
      description="Уроки модуля и прогресс."
      values={[{ label: 'module', value: module }]}
    />
  )
}
