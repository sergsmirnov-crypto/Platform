import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Медиатека' }

export default function MediaLibraryPage() {
  return (
    <PagePlaceholder
      title="Медиатека"
      stage="Этап 5"
      description="Все загруженные видео и файлы, статус обработки."
    />
  )
}
