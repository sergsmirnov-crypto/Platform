import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Оферта' }

export default function OfferPage() {
  return <PagePlaceholder title="Оферта" stage="Этап 9" description="Условия участия в клубе." />
}
