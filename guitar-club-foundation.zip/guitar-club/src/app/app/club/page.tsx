import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Клуб' }

export default function ClubHubPage() {
  return (
    <PagePlaceholder title="Клуб" stage="Этап 8" description="О клубе, кураторы, новости, чаты." />
  )
}
