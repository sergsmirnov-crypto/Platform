import 'server-only'

import { and, asc, count, desc, eq, ilike, inArray, isNotNull, lte, or, sql } from 'drizzle-orm'

import { avatarUrlFor } from '@/modules/identity'
import { users } from '@/modules/identity/schema'
import { mediaAssets } from '@/modules/media/schema'
import { attachments } from '@/modules/media/schema'
import { tags, taggables } from '@/modules/taxonomy/schema'
import { appConfig } from '@/shared/config/app.config'
import { db } from '@/shared/db'

import { pageOffset } from './catalog-filters'
import { compareLevels, resolveSectionPlayback, sectionDuration, tuningLabel } from './domain'
import { arrangements, arrangementSections, songs } from './schema'

import type { CatalogFilters } from './catalog-filters'
import type { Level } from './domain'
import type {
  ArrangementView,
  CatalogPage,
  MaterialView,
  SectionView,
  SongCard,
  SongView,
} from './types'

/**
 * Запросы к базе, связанные с разборами.
 *
 * Единственное место модуля, где есть SQL. Наружу отдаются готовые
 * структуры из `types.ts`, а не строки таблиц: интерфейс не должен знать
 * ни имён колонок, ни того, что уровни лежат в отдельной таблице.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПРО ВИДИМОСТЬ
 *
 * Условие «показывать только опубликованное» повторяется в каждом
 * запросе, и забыть его — значит показать участникам черновики.
 * Поэтому оно собрано одной функцией `visibilityCondition`, а решение
 * «можно ли видеть черновики» принимает сервис по правам, а не запрос.
 * ─────────────────────────────────────────────────────────────────
 */

/**
 * Условие видимости.
 *
 * Запланированная публикация открывается сама, по времени: сравнение
 * с текущим моментом делает база, чтобы разбор не ждал захода куратора.
 */
function visibilityCondition(includeDrafts: boolean) {
  if (includeDrafts) return undefined

  return or(
    eq(songs.status, 'published'),
    and(
      eq(songs.status, 'scheduled'),
      isNotNull(songs.publishedAt),
      lte(songs.publishedAt, sql`now()`),
    ),
  )
}

function isPublicRow(status: string, publishedAt: Date | null, now: Date): boolean {
  if (status === 'published') return true

  return status === 'scheduled' && publishedAt !== null && publishedAt <= now
}

function orderFor(sort: CatalogFilters['sort']) {
  switch (sort) {
    case 'popular':
      return [desc(songs.popularityScore), desc(songs.publishedAt)]
    case 'alphabet':
      return [asc(songs.artist), asc(songs.title)]
    case 'level':
      // Порядок по уровню собирается в приложении: у песни несколько
      // уровней сразу, и «самый простой из имеющихся» база одной
      // колонкой не отсортирует
      return [asc(songs.artist), asc(songs.title)]
    default:
      return [desc(songs.publishedAt), desc(songs.createdAt)]
  }
}

/**
 * Каталог разборов.
 *
 * Два запроса вместо одного: сначала страница песен, потом их варианты.
 * Соединение одним запросом дало бы по строке на каждый вариант, и
 * «двадцать четыре песни на странице» превратилось бы в непредсказуемое
 * число строк — постраничная навигация сломалась бы.
 */
export async function findCatalogPage(filters: CatalogFilters): Promise<CatalogPage> {
  const pageSize = appConfig.catalog.pageSize
  const now = new Date()

  const conditions = [visibilityCondition(filters.includeDrafts)]

  if (filters.query) {
    const pattern = `%${filters.query}%`
    conditions.push(or(ilike(songs.title, pattern), ilike(songs.artist, pattern)))
  }

  if (filters.tunings.length > 0) {
    conditions.push(inArray(songs.tuning, filters.tunings))
  }

  if (filters.tags.length > 0) {
    conditions.push(
      sql`exists (
        select 1 from ${taggables}
        join ${tags} on ${tags.id} = ${taggables.tagId}
        where ${taggables.entityType} = 'song'
          and ${taggables.entityId} = ${songs.id}
          and ${tags.slug} in ${filters.tags}
      )`,
    )
  }

  // Уровень и куратор — свойства варианта, а не песни. Поэтому условие
  // формулируется как «у песни есть подходящий вариант»
  if (filters.levels.length > 0 || filters.curatorId) {
    const inner = [eq(arrangements.songId, songs.id)]

    if (filters.levels.length > 0) {
      inner.push(inArray(arrangements.level, filters.levels))
    }
    if (filters.curatorId) {
      inner.push(eq(arrangements.curatorId, filters.curatorId))
    }

    conditions.push(sql`exists (select 1 from ${arrangements} where ${and(...inner)})`)
  }

  const where = and(...conditions.filter(Boolean))

  const [totalRow] = await db.select({ value: count() }).from(songs).where(where)
  const total = totalRow?.value ?? 0

  const rows = await db
    .select({
      id: songs.id,
      slug: songs.slug,
      title: songs.title,
      artist: songs.artist,
      year: songs.year,
      tuning: songs.tuning,
      status: songs.status,
      publishedAt: songs.publishedAt,
      coverUrl: mediaAssets.url,
    })
    .from(songs)
    .leftJoin(mediaAssets, eq(mediaAssets.id, songs.coverAssetId))
    .where(where)
    .orderBy(...orderFor(filters.sort))
    .limit(pageSize)
    .offset(pageOffset(filters.page, pageSize))

  const levelsBySong = await findLevelsForSongs(rows.map((row) => row.id))

  const items: SongCard[] = rows.map((row) => {
    const levels = levelsBySong.get(row.id) ?? []

    return {
      id: row.id,
      slug: row.slug,
      title: row.title,
      artist: row.artist,
      year: row.year,
      coverUrl: row.coverUrl,
      tuning: row.tuning,
      tuningLabel: tuningLabel(row.tuning),
      levels,
      arrangementCount: levels.length,
      status: row.status,
      publishedAt: row.publishedAt,
      isPublic: isPublicRow(row.status, row.publishedAt, now),
    }
  })

  if (filters.sort === 'level') {
    items.sort((a, b) => {
      const first = a.levels[0]
      const second = b.levels[0]

      if (!first) return 1
      if (!second) return -1

      return compareLevels(first, second)
    })
  }

  return {
    items,
    total,
    page: filters.page,
    pageCount: Math.max(1, Math.ceil(total / pageSize)),
  }
}

/** Какие уровни разобраны у каждой песни — для бейджей на карточках */
async function findLevelsForSongs(songIds: string[]): Promise<Map<string, Level[]>> {
  const result = new Map<string, Level[]>()
  if (songIds.length === 0) return result

  const rows = await db
    .select({ songId: arrangements.songId, level: arrangements.level })
    .from(arrangements)
    .where(inArray(arrangements.songId, songIds))

  for (const row of rows) {
    const existing = result.get(row.songId) ?? []
    if (!existing.includes(row.level)) existing.push(row.level)
    result.set(row.songId, existing)
  }

  for (const levels of result.values()) levels.sort(compareLevels)

  return result
}

/**
 * Страница песни целиком.
 *
 * Собирается четырьмя запросами: песня, варианты, части, материалы
 * и метки. Можно было бы одним с соединениями — и получить произведение
 * строк, которое потом всё равно пришлось бы разбирать в приложении,
 * только уже вслепую.
 */
export async function findSongBySlug(
  slug: string,
  includeDrafts: boolean,
): Promise<SongView | null> {
  const now = new Date()

  const [song] = await db
    .select({
      id: songs.id,
      slug: songs.slug,
      title: songs.title,
      artist: songs.artist,
      album: songs.album,
      year: songs.year,
      description: songs.description,
      tuning: songs.tuning,
      capo: songs.capo,
      tempoBpm: songs.tempoBpm,
      musicKey: songs.musicKey,
      status: songs.status,
      publishedAt: songs.publishedAt,
      coverUrl: mediaAssets.url,
    })
    .from(songs)
    .leftJoin(mediaAssets, eq(mediaAssets.id, songs.coverAssetId))
    .where(and(eq(songs.slug, slug), visibilityCondition(includeDrafts)))
    .limit(1)

  if (!song) return null

  const [arrangementViews, songTags, songMaterials] = await Promise.all([
    findArrangements(song.id, includeDrafts),
    findTags(song.id),
    findMaterials('song', [song.id]),
  ])

  return {
    ...song,
    tuningLabel: tuningLabel(song.tuning),
    isPublic: isPublicRow(song.status, song.publishedAt, now),
    tags: songTags,
    arrangements: arrangementViews,
    materials: songMaterials.get(song.id) ?? [],
  }
}

async function findArrangements(
  songId: string,
  includeDrafts: boolean,
): Promise<ArrangementView[]> {
  const rows = await db
    .select({
      id: arrangements.id,
      level: arrangements.level,
      title: arrangements.title,
      summary: arrangements.summary,
      estimatedMinutes: arrangements.estimatedMinutes,
      status: arrangements.status,
      orderIndex: arrangements.orderIndex,
      videoAssetId: arrangements.videoAssetId,
      curatorId: users.id,
      curatorName: users.displayName,
      curatorAvatarId: users.avatarId,
    })
    .from(arrangements)
    .leftJoin(users, eq(users.id, arrangements.curatorId))
    .where(eq(arrangements.songId, songId))
    .orderBy(asc(arrangements.orderIndex))

  const visible = includeDrafts ? rows : rows.filter((row) => row.status === 'published')
  if (visible.length === 0) return []

  const ids = visible.map((row) => row.id)

  const [sectionRows, materialsByArrangement] = await Promise.all([
    db
      .select()
      .from(arrangementSections)
      .where(inArray(arrangementSections.arrangementId, ids))
      .orderBy(asc(arrangementSections.orderIndex)),
    findMaterials('arrangement', ids),
  ])

  return visible
    .map((row) => {
      const own = sectionRows.filter((section) => section.arrangementId === row.id)

      const sections: SectionView[] = own.map((section) => ({
        id: section.id,
        title: section.title,
        description: section.description,
        orderIndex: section.orderIndex,
        durationSec: sectionDuration(section),
        playback: resolveSectionPlayback(section, row.videoAssetId),
      }))

      return {
        id: row.id,
        level: row.level,
        title: row.title,
        summary: row.summary,
        estimatedMinutes: row.estimatedMinutes,
        status: row.status,
        isPublic: row.status === 'published',
        curator: row.curatorId
          ? {
              id: row.curatorId,
              displayName: row.curatorName ?? 'Куратор',
              // Адрес фотографии собирает модуль участников: как именно
              // он устроен, разборам знать незачем
              avatarUrl: avatarUrlFor(row.curatorId, row.curatorAvatarId, 'sm'),
            }
          : null,
        sections,
        materials: materialsByArrangement.get(row.id) ?? [],
        totalDurationSec: sections.reduce((sum, section) => sum + (section.durationSec ?? 0), 0),
      }
    })
    .sort((a, b) => compareLevels(a.level, b.level))
}

async function findTags(songId: string) {
  return db
    .select({ id: tags.id, slug: tags.slug, name: tags.name, kind: tags.kind })
    .from(taggables)
    .innerJoin(tags, eq(tags.id, taggables.tagId))
    .where(and(eq(taggables.entityType, 'song'), eq(taggables.entityId, songId)))
    .orderBy(asc(tags.kind), asc(tags.orderIndex))
}

/** Материалы, сгруппированные по объекту, к которому привязаны */
async function findMaterials(
  entityType: 'song' | 'arrangement',
  entityIds: string[],
): Promise<Map<string, MaterialView[]>> {
  const result = new Map<string, MaterialView[]>()
  if (entityIds.length === 0) return result

  const rows = await db
    .select({
      id: attachments.id,
      entityId: attachments.entityId,
      title: attachments.title,
      orderIndex: attachments.orderIndex,
      mediaAssetId: mediaAssets.id,
      kind: mediaAssets.kind,
      assetTitle: mediaAssets.title,
      isDownloadable: mediaAssets.isDownloadable,
    })
    .from(attachments)
    .innerJoin(mediaAssets, eq(mediaAssets.id, attachments.mediaAssetId))
    .where(and(eq(attachments.entityType, entityType), inArray(attachments.entityId, entityIds)))
    .orderBy(asc(attachments.orderIndex))

  for (const row of rows) {
    const list = result.get(row.entityId) ?? []
    list.push({
      id: row.id,
      title: row.title ?? row.assetTitle ?? 'Материал',
      kind: row.kind,
      mediaAssetId: row.mediaAssetId,
      isDownloadable: row.isDownloadable,
    })
    result.set(row.entityId, list)
  }

  return result
}

/** Все адреса разборов — нужно, чтобы новый адрес не повторил существующий */
export async function findTakenSlugs(prefix: string): Promise<string[]> {
  const rows = await db
    .select({ slug: songs.slug })
    .from(songs)
    .where(ilike(songs.slug, `${prefix}%`))

  return rows.map((row) => row.slug)
}
