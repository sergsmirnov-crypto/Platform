# Шаг 4.1 — Профиль участника

## Применение

```bash
unzip -o step-4.1-profile.zip -d /путь/к/guitar-club
cd /путь/к/guitar-club
pnpm db:migrate     # ⚠️ обязательно: две новые колонки
pnpm check && pnpm build
```

Новых зависимостей нет, удалять ничего не нужно.
Ожидается: **193 теста**, ошибок нет, сборка успешна.

> ⚠️ Архивы 3.2, 3.3 и 3.4 должны быть применены раньше.

## Миграция

`drizzle/0002_profile_fields.sql` добавляет в таблицу участников
`favorite_artists` и `favorite_genres`. Обе с пустым значением
по умолчанию, поэтому существующие записи не страдают и откат
безопасен.

## Что проверить в браузере

```bash
docker compose up -d && pnpm db:migrate && pnpm db:seed && pnpm dev
```

| Где                                  | Ожидание                                                       |
| ------------------------------------ | ---------------------------------------------------------------- |
| `/app/me`                            | Карточка с именем и пять переходов в личные разделы             |
| Аватар в шапке и в кабинете          | Нейтральный силуэт, не буква и не пустой круг                   |
| `/app/me/profile`                    | Форма со всеми полями, заполненная текущими данными             |
| Стереть имя, сохранить               | Ошибка под полем имени, остальные поля не тронуты               |
| Ввести `vk.com/id1` в ссылку         | Ошибка: ссылка должна начинаться с https://                     |
| Вставить «Кино, Ария, ДДТ» одной строкой | Три отдельных значения, а не одно                           |
| Ввести исполнителя дважды            | Второй раз не добавляется                                       |
| Backspace в пустом поле исполнителей | Убирает последнее значение                                      |
| Год начала игры 2050                 | Ошибка: год не может быть в будущем                             |
| Сохранить и обновить страницу        | Данные на месте                                                 |
| Изменить имя и открыть `/app`        | Приветствие с новым именем                                      |
| Телефонная ширина                    | Жанры кнопками в несколько рядов, всё нажимается пальцем        |

## Состав

**Новые файлы**

```
src/modules/identity/profile.ts        правила профиля, справочники, склонения
src/modules/identity/profile.test.ts   17 тестов
src/ui/primitives/avatar.tsx           аватар с силуэтом
src/ui/primitives/chips-input.tsx      ввод списка значений
src/ui/primitives/toggle-group.tsx     выбор нескольких из списка
src/app/app/me/_components/profile-form.tsx
drizzle/0002_profile_fields.sql        миграция
```

**Изменённые файлы**

```
src/modules/identity/schema.ts        две новые колонки
src/modules/identity/repository.ts    чтение и запись профиля
src/modules/identity/actions.ts       действие saveProfile
src/modules/identity/index.ts         экспорты
src/app/app/me/page.tsx               личный кабинет
src/app/app/me/profile/page.tsx       страница профиля
src/app/app/_components/profile-menu.tsx  аватар вместо буквы
src/app/app/_components/app-header.tsx    передача аватара
src/ui/primitives/input.tsx, index.ts
docs/CHANGELOG.md, ROADMAP.md
```

**Коммит**

```
feat(profile): add member profile with editing
```
