import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

type Props = { params: Promise<{ slug: string }> }

export const metadata = { title: 'Профиль куратора' }

export default async function CuratorPage({ params }: Props) {
  const { slug } = await params

  return (
    <PagePlaceholder
      title="Профиль куратора"
      stage="Этап 8"
      description="Био, оборудование, его разборы, эфиры и уроки."
      values={[{ label: 'slug', value: slug }]}
    />
  )
}
