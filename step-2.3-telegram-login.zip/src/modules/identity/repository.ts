import 'server-only'

import { and, desc, eq, gt, inArray, isNull, lt, ne, or } from 'drizzle-orm'
import { v7 as uuidv7 } from 'uuid'

import { db } from '@/shared/db'

import { authIdentities, sessions, users } from './schema'

import type { SessionForLimit } from './session-policy'
import type { SessionUser } from './types'

/**
 * Запросы к базе, связанные с людьми и сессиями.
 *
 * Единственное место в модуле, где есть SQL. Сервис работает с уже
 * полученными данными и ничего не знает о таблицах — благодаря этому
 * логику можно менять, не трогая запросы, и наоборот.
 */

/** Сессия вместе с человеком, которому она принадлежит: один запрос вместо двух */
export type SessionWithUser = {
  id: string
  userId: string
  createdAt: Date
  lastUsedAt: Date
  expiresAt: Date
  revokedAt: Date | null
  user: SessionUser
}

export async function findSessionByTokenHash(tokenHash: string): Promise<SessionWithUser | null> {
  const rows = await db
    .select({
      id: sessions.id,
      userId: sessions.userId,
      createdAt: sessions.createdAt,
      lastUsedAt: sessions.lastUsedAt,
      expiresAt: sessions.expiresAt,
      revokedAt: sessions.revokedAt,
      userDisplayName: users.displayName,
      userAvatarUrl: users.avatarUrl,
      userOnboardingDoneAt: users.onboardingDoneAt,
      userDeletedAt: users.deletedAt,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(eq(sessions.tokenHash, tokenHash))
    .limit(1)

  const row = rows[0]
  if (!row) return null

  // Удалённый участник не должен входить по старой сессии
  if (row.userDeletedAt !== null) return null

  return {
    id: row.id,
    userId: row.userId,
    createdAt: row.createdAt,
    lastUsedAt: row.lastUsedAt,
    expiresAt: row.expiresAt,
    revokedAt: row.revokedAt,
    user: {
      id: row.userId,
      displayName: row.userDisplayName,
      avatarUrl: row.userAvatarUrl,
      onboardingDoneAt: row.userOnboardingDoneAt,
    },
  }
}

export type CreateSessionInput = {
  userId: string
  tokenHash: string
  expiresAt: Date
  userAgent: string | null
  ipHash: string | null
}

export async function insertSession(input: CreateSessionInput): Promise<string> {
  const id = uuidv7()

  await db.insert(sessions).values({
    id,
    userId: input.userId,
    tokenHash: input.tokenHash,
    expiresAt: input.expiresAt,
    userAgent: input.userAgent,
    ipHash: input.ipHash,
  })

  return id
}

/** Продлевает срок сессии и отмечает момент последнего использования */
export async function touchSession(sessionId: string, expiresAt: Date): Promise<void> {
  await db
    .update(sessions)
    .set({ lastUsedAt: new Date(), expiresAt })
    .where(eq(sessions.id, sessionId))
}

/** Действующие сессии человека — для списка устройств и проверки лимита */
export async function findActiveSessions(userId: string): Promise<SessionForLimit[]> {
  const rows = await db
    .select({ id: sessions.id, lastUsedAt: sessions.lastUsedAt })
    .from(sessions)
    .where(
      and(
        eq(sessions.userId, userId),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(sessions.lastUsedAt))

  return rows
}

/** Подробности о действующих сессиях — для экрана настроек */
export async function findActiveSessionDetails(userId: string) {
  return db
    .select({
      id: sessions.id,
      userAgent: sessions.userAgent,
      createdAt: sessions.createdAt,
      lastUsedAt: sessions.lastUsedAt,
      expiresAt: sessions.expiresAt,
    })
    .from(sessions)
    .where(
      and(
        eq(sessions.userId, userId),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(sessions.lastUsedAt))
}

/**
 * Закрывает сессии.
 *
 * Записи не удаляются, а помечаются отозванными: так в журнале остаётся след
 * того, что вход был, и можно разобрать спорный случай.
 */
export async function revokeSessions(sessionIds: readonly string[]): Promise<void> {
  if (sessionIds.length === 0) return

  await db
    .update(sessions)
    .set({ revokedAt: new Date() })
    .where(and(inArray(sessions.id, [...sessionIds]), isNull(sessions.revokedAt)))
}

/** Закрывает все сессии человека. Используется при снятии доступа */
export async function revokeAllSessions(userId: string, exceptSessionId?: string): Promise<void> {
  const conditions = [eq(sessions.userId, userId), isNull(sessions.revokedAt)]

  // «Выйти на всех остальных устройствах»: текущая сессия остаётся живой
  if (exceptSessionId) {
    conditions.push(ne(sessions.id, exceptSessionId))
  }

  await db
    .update(sessions)
    .set({ revokedAt: new Date() })
    .where(and(...conditions))
}

/**
 * Убирает из базы давно закрытые и просроченные сессии.
 *
 * Запускается фоновой задачей. Без уборки таблица растёт вечно:
 * за год у 250 участников накопятся десятки тысяч мёртвых записей.
 */
export async function deleteStaleSessions(before: Date): Promise<number> {
  const removed = await db
    .delete(sessions)
    .where(or(lt(sessions.expiresAt, before), lt(sessions.revokedAt, before)))
    .returning({ id: sessions.id })

  return removed.length
}

/** Человек по идентификатору. Удалённые не возвращаются */
export async function findUserById(userId: string): Promise<SessionUser | null> {
  const rows = await db
    .select({
      id: users.id,
      displayName: users.displayName,
      avatarUrl: users.avatarUrl,
      onboardingDoneAt: users.onboardingDoneAt,
    })
    .from(users)
    .where(and(eq(users.id, userId), isNull(users.deletedAt)))
    .limit(1)

  return rows[0] ?? null
}

/** Отмечает, что человек заходил. Используется для статистики активности */
export async function touchUserLastSeen(userId: string): Promise<void> {
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, userId))
}

/**
 * Все участники — только для служебного входа при разработке.
 * В производственной сборке эта функция не вызывается.
 */
export async function findAllUsersForDevelopment(): Promise<SessionUser[]> {
  return db
    .select({
      id: users.id,
      displayName: users.displayName,
      avatarUrl: users.avatarUrl,
      onboardingDoneAt: users.onboardingDoneAt,
    })
    .from(users)
    .where(isNull(users.deletedAt))
    .orderBy(users.createdAt)
    .limit(50)
}

/** Способ входа вместе с человеком, которому он принадлежит */
export type IdentityWithUser = { userId: string; user: SessionUser }

/** Ищет человека по его идентификатору в Telegram */
export async function findUserByTelegramId(telegramId: string): Promise<IdentityWithUser | null> {
  const rows = await db
    .select({
      userId: users.id,
      displayName: users.displayName,
      avatarUrl: users.avatarUrl,
      onboardingDoneAt: users.onboardingDoneAt,
      deletedAt: users.deletedAt,
    })
    .from(authIdentities)
    .innerJoin(users, eq(users.id, authIdentities.userId))
    .where(
      and(eq(authIdentities.provider, 'telegram'), eq(authIdentities.providerUserId, telegramId)),
    )
    .limit(1)

  const row = rows[0]
  if (!row || row.deletedAt !== null) return null

  return {
    userId: row.userId,
    user: {
      id: row.userId,
      displayName: row.displayName,
      avatarUrl: row.avatarUrl,
      onboardingDoneAt: row.onboardingDoneAt,
    },
  }
}

export type TelegramProfile = {
  telegramId: string
  displayName: string
  avatarUrl: string | null
  /** Всё, что прислал Telegram: имя пользователя, фамилия. Для справки */
  providerData: Record<string, unknown>
}

/**
 * Создаёт участника вместе со способом входа.
 *
 * Обе записи создаются в одной транзакции: человек без способа войти
 * или способ входа без человека — это сломанное состояние, которое
 * потом придётся чинить руками.
 */
export async function createUserWithTelegramIdentity(
  profile: TelegramProfile,
): Promise<IdentityWithUser> {
  const userId = uuidv7()

  await db.transaction(async (tx) => {
    await tx.insert(users).values({
      id: userId,
      displayName: profile.displayName,
      avatarUrl: profile.avatarUrl,
      lastSeenAt: new Date(),
    })

    await tx.insert(authIdentities).values({
      id: uuidv7(),
      userId,
      provider: 'telegram',
      providerUserId: profile.telegramId,
      providerData: profile.providerData,
      isPrimary: true,
      verifiedAt: new Date(),
    })
  })

  return {
    userId,
    user: {
      id: userId,
      displayName: profile.displayName,
      avatarUrl: profile.avatarUrl,
      onboardingDoneAt: null,
    },
  }
}

/**
 * Обновляет сведения, пришедшие от Telegram.
 *
 * Имя и фотография участника платформы НЕ перезаписываются: человек мог
 * поменять их у нас осознанно, и затирать это при каждом входе неправильно.
 * Обновляется только копия данных поставщика — она нужна для поддержки
 * и для поиска участника по имени пользователя в Telegram.
 */
export async function updateTelegramIdentityData(
  telegramId: string,
  providerData: Record<string, unknown>,
): Promise<void> {
  await db
    .update(authIdentities)
    .set({ providerData, updatedAt: new Date() })
    .where(
      and(eq(authIdentities.provider, 'telegram'), eq(authIdentities.providerUserId, telegramId)),
    )
}

/** Идентификатор Telegram по идентификатору участника. Нужен для сверки подписок */
export async function findTelegramIdByUserId(userId: string): Promise<string | null> {
  const rows = await db
    .select({ providerUserId: authIdentities.providerUserId })
    .from(authIdentities)
    .where(and(eq(authIdentities.userId, userId), eq(authIdentities.provider, 'telegram')))
    .limit(1)

  return rows[0]?.providerUserId ?? null
}
