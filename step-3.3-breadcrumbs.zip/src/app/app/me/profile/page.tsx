import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Профиль' }

export default function ProfilePage() {
  return (
    <PagePlaceholder
      title="Профиль"
      stage="Этап 4"
      description="Имя, город, стаж игры, любимые исполнители."
    />
  )
}
