import 'server-only'

import { and, asc, desc, eq, gte, inArray, lt, or, sql } from 'drizzle-orm'

import { users } from '@/modules/identity/schema'
import { mediaAssets } from '@/modules/media/schema'
import { songs } from '@/modules/songs/schema'
import { db } from '@/shared/db'

import { streamChapters, streamSongs, streams } from './schema'

import type { StreamState } from './schema'

/**
 * Запросы к базе — единственное место в модуле, где есть SQL.
 *
 * Черновики отсекаются здесь, а не в сервисе: условие видимости должно
 * быть частью запроса, иначе однажды кто-нибудь отфильтрует их уже
 * после выборки, и черновик успеет уехать в браузер вместе с ответом.
 */

function visible(includeDrafts: boolean) {
  return includeDrafts ? undefined : eq(streams.status, 'published')
}

export type StreamRow = {
  id: string
  slug: string
  title: string
  description: string | null
  startsAt: Date
  endedAt: Date | null
  state: StreamState
  status: string
  joinUrl: string | null
  videoAssetId: string | null
  curatorName: string | null
  coverUrl: string | null
  durationSec: number | null
}

/** Общий набор колонок: и списки, и страница показывают одно и то же */
const streamColumns = {
  id: streams.id,
  slug: streams.slug,
  title: streams.title,
  description: streams.description,
  startsAt: streams.startsAt,
  endedAt: streams.endedAt,
  state: streams.state,
  status: streams.status,
  joinUrl: streams.joinUrl,
  videoAssetId: streams.videoAssetId,
  curatorName: users.displayName,
  coverUrl: sql<string | null>`null`,
  durationSec: mediaAssets.durationSec,
}

function baseQuery() {
  return db
    .select(streamColumns)
    .from(streams)
    .leftJoin(users, eq(users.id, streams.curatorId))
    .leftJoin(mediaAssets, eq(mediaAssets.id, streams.videoAssetId))
}

/**
 * Ближайшие эфиры.
 *
 * Граница — не «дата больше сегодняшней», а «начало позже, чем три часа
 * назад»: идущий прямо сейчас эфир начался в прошлом, но место ему
 * в ближайших, а не в архиве. Три часа — тот же запас, что в правилах
 * `domain.ts`.
 */
export async function findUpcoming(includeDrafts: boolean, limit: number): Promise<StreamRow[]> {
  const since = new Date(Date.now() - 3 * 60 * 60 * 1000)

  return baseQuery()
    .where(
      and(
        visible(includeDrafts),
        gte(streams.startsAt, since),
        // Отменённые в ближайших не показываем: они уже не состоятся,
        // а место в списке занимают
        or(eq(streams.state, 'scheduled'), eq(streams.state, 'live')),
      ),
    )
    .orderBy(asc(streams.startsAt))
    .limit(limit)
}

export type ArchiveQuery = {
  includeDrafts: boolean
  query: string | null
  curatorId: string | null
  page: number
  pageSize: number
}

/**
 * Архив записей.
 *
 * Всё, что уже не в будущем, — включая эфиры, чья запись ещё готовится:
 * человек, пропустивший вчерашний эфир, должен увидеть, что он был,
 * а не решить, что эфира не случилось.
 */
export async function findArchive(
  input: ArchiveQuery,
): Promise<{ items: StreamRow[]; total: number }> {
  const since = new Date(Date.now() - 3 * 60 * 60 * 1000)

  const conditions = [visible(input.includeDrafts), lt(streams.startsAt, since)]

  if (input.query) {
    // Тот же полнотекстовый поиск, что у разборов (ADR-0017), только
    // без исправления раскладки: тему эфира ищут точнее, чем песню
    conditions.push(sql`${streams.searchVector} @@ plainto_tsquery('russian', ${input.query})`)
  }

  if (input.curatorId) {
    conditions.push(eq(streams.curatorId, input.curatorId))
  }

  const where = and(...conditions)

  const [items, [counted]] = await Promise.all([
    baseQuery()
      .where(where)
      .orderBy(desc(streams.startsAt))
      .limit(input.pageSize)
      .offset((input.page - 1) * input.pageSize),
    db
      .select({ value: sql<number>`count(*)::int` })
      .from(streams)
      .where(where),
  ])

  return { items, total: counted?.value ?? 0 }
}

export async function findStreamBySlug(
  slug: string,
  includeDrafts: boolean,
): Promise<StreamRow | null> {
  const [row] = await baseQuery()
    .where(and(eq(streams.slug, slug), visible(includeDrafts)))
    .limit(1)

  return row ?? null
}

export type ChapterRow = { id: string; title: string; startSec: number }

export async function findChapters(streamId: string): Promise<ChapterRow[]> {
  return db
    .select({
      id: streamChapters.id,
      title: streamChapters.title,
      startSec: streamChapters.startSec,
    })
    .from(streamChapters)
    .where(eq(streamChapters.streamId, streamId))
    .orderBy(asc(streamChapters.orderIndex), asc(streamChapters.startSec))
}

export type StreamSongRow = { id: string; slug: string; title: string; artist: string }

export async function findStreamSongs(streamId: string): Promise<StreamSongRow[]> {
  return db
    .select({
      id: songs.id,
      slug: songs.slug,
      title: songs.title,
      artist: songs.artist,
    })
    .from(streamSongs)
    .innerJoin(songs, eq(songs.id, streamSongs.songId))
    .where(and(eq(streamSongs.streamId, streamId), eq(songs.status, 'published')))
    .orderBy(asc(songs.title))
}

/**
 * Эфиры, в которых разбирали эту песню.
 *
 * Обратная сторона связи, и полезная: человек, застрявший на песне,
 * находит полтора часа живого разбора именно её.
 */
export async function findStreamsForSong(
  songId: string,
  includeDrafts: boolean,
  limit = 5,
): Promise<StreamRow[]> {
  const ids = await db
    .select({ streamId: streamSongs.streamId })
    .from(streamSongs)
    .where(eq(streamSongs.songId, songId))

  if (ids.length === 0) return []

  return baseQuery()
    .where(
      and(
        inArray(
          streams.id,
          ids.map((row) => row.streamId),
        ),
        visible(includeDrafts),
      ),
    )
    .orderBy(desc(streams.startsAt))
    .limit(limit)
}
