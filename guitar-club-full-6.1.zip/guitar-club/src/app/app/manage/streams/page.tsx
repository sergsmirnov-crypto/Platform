import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Эфиры: управление' }

export default function ManageStreamsPage() {
  return (
    <PagePlaceholder
      title="Эфиры: управление"
      stage="Этап 7"
      description="Планирование эфиров и публикация записей."
    />
  )
}
