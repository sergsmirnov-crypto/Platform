import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'О клубе' }

export default function AboutClubPage() {
  return (
    <PagePlaceholder
      title="О клубе"
      stage="Этап 8"
      description="Как устроено обучение и как пользоваться платформой."
    />
  )
}
