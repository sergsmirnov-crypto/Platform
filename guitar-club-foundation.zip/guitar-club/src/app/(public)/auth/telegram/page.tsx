import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Вход через Telegram' }

export default function TelegramCallbackPage() {
  return (
    <PagePlaceholder
      title="Вход через Telegram"
      stage="Этап 2"
      description="Возврат из виджета Telegram: проверка подписи и создание сессии."
    />
  )
}
