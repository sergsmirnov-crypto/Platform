import { PagePlaceholder } from '../../../_components/page-placeholder'

type Props = { params: Promise<{ id: string }> }

export const metadata = { title: 'Редактор разбора' }

export default async function ManageSongEditorPage({ params }: Props) {
  const { id } = await params

  return (
    <PagePlaceholder
      title="Редактор разбора"
      stage="Этап 5"
      description="Песня, варианты по уровням, части, материалы, публикация."
      values={[{ label: 'id', value: id }]}
    />
  )
}
