import { ComingSoonBlock } from './_components/dashboard/coming-soon-block'
import { GreetingBlock } from './_components/dashboard/greeting-block'
import { SubscriptionBlock } from './_components/dashboard/subscription-block'
import { TelegramBlock } from './_components/dashboard/telegram-block'
import { getViewer } from './_lib/viewer'

export const metadata = { title: 'Главная' }

/**
 * Главная страница.
 *
 * ─────────────────────────────────────────────────────────────────
 * УСТРОЕНА КАК СПИСОК НЕЗАВИСИМЫХ БЛОКОВ.
 * Каждый блок — отдельный файл, сам берёт свои данные и сам решает,
 * показываться ли: если данных нет, возвращает пустоту.
 * ─────────────────────────────────────────────────────────────────
 *
 * Поэтому добавить блок — это создать файл и вписать сюда строку,
 * а не переделать страницу. Так и появятся на этапах 5–7 «Продолжить»,
 * подборка недели, ближайший эфир и ленты новинок: страница к тому
 * моменту не изменится.
 *
 * Сейчас блоков четыре — те, для которых уже есть данные. Собирать
 * остальные на выдуманных числах не стали: их пришлось бы переписывать
 * дважды, а участник всё равно увидел бы пустые полки (PRD v0.1 §1.3,
 * принцип «всегда есть что открыть» начинает работать с появлением
 * содержимого, а не разметки).
 *
 * Хлебных крошек здесь нет намеренно: вести с главной на главную незачем.
 * Поэтому и `PageIntro` не используется — приветствие само является
 * заголовком страницы.
 */
export default async function DashboardPage() {
  const viewer = await getViewer()

  if (!viewer.session) return null

  return (
    <div className="flex max-w-5xl flex-col gap-8">
      <GreetingBlock displayName={viewer.session.user.displayName} />

      <SubscriptionBlock userId={viewer.session.user.id} />
      <TelegramBlock />
      <ComingSoonBlock />
    </div>
  )
}
