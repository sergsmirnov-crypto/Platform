import { redirect } from 'next/navigation'

import { getRequestOrigin, setSessionCookie } from '@/modules/identity/cookie'
import { safeReturnTo } from '@/modules/identity/return-to'
import { signInWithTelegram } from '@/modules/identity/telegram-login'
import { RETURN_TO_PARAM } from '@/shared/config/constants'
import { serverEnv } from '@/shared/config/env.server'
import { getLogger } from '@/shared/logger'
import { routes } from '@/shared/routes'
import { checkRateLimit } from '@/shared/security/rate-limit'
import { verifyLoginWidget } from '@/shared/telegram'

import type { NextRequest } from 'next/server'

/**
 * Возврат из виджета входа Telegram.
 *
 * Виджет настроен на перенаправление: после подтверждения Telegram сам
 * открывает этот адрес и передаёт данные человека параметрами. Обработчик
 * проверяет подпись, открывает сессию и уводит человека внутрь платформы.
 *
 * Почему обработчик адреса, а не страница с формой: сюда приходит обычный
 * переход по ссылке, а не отправка формы. Здесь нечего показывать —
 * нужно поставить cookie и перенаправить.
 *
 * Порядок проверок важен: сначала ограничение частоты, потом подпись.
 * Так перебор упирается в лимит, не нагружая проверку подписи и базу.
 */

/** Причины отказа, которые показываются человеку на странице входа */
const LOGIN_ERROR = {
  RATE_LIMITED: 'too_many',
  INVALID: 'invalid',
  EXPIRED: 'expired',
  UNAVAILABLE: 'unavailable',
} as const

function failWith(reason: string): never {
  redirect(`${routes.home()}?error=${reason}`)
}

export async function GET(request: NextRequest): Promise<never> {
  const log = getLogger()
  const params = request.nextUrl.searchParams

  const botToken = serverEnv.TELEGRAM_BOT_TOKEN
  if (!botToken) {
    log.error('вход через Telegram невозможен: не задан TELEGRAM_BOT_TOKEN')
    failWith(LOGIN_ERROR.UNAVAILABLE)
  }

  const origin = await getRequestOrigin()

  const allowed = checkRateLimit({
    action: 'login',
    subject: origin.ip ?? 'unknown',
    limit: 10,
    windowSeconds: 300,
  }).allowed

  if (!allowed) {
    log.warn('превышено число попыток входа')
    failWith(LOGIN_ERROR.RATE_LIMITED)
  }

  const fields: Record<string, string> = {}
  for (const [key, value] of params.entries()) {
    if (key !== RETURN_TO_PARAM) fields[key] = value
  }

  const verified = verifyLoginWidget(fields, botToken)

  if (!verified.ok) {
    // Причину подделки наружу не сообщаем: она полезна только тому,
    // кто подбирает подпись. Истёкшие данные — отдельный случай,
    // там человеку надо просто нажать «войти» ещё раз
    log.warn({ reason: verified.reason }, 'вход через Telegram отклонён')
    failWith(verified.reason === 'expired' ? LOGIN_ERROR.EXPIRED : LOGIN_ERROR.INVALID)
  }

  const { token, expiresAt, isNewUser } = await signInWithTelegram(verified.data, origin)
  await setSessionCookie(token, expiresAt)

  // Новичка ведём знакомиться, остальных — туда, куда они шли
  const destination = isNewUser
    ? routes.app.onboarding()
    : safeReturnTo(params.get(RETURN_TO_PARAM))

  redirect(destination)
}
