import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Кураторы' }

export default function CuratorsPage() {
  return (
    <PagePlaceholder
      title="Кураторы"
      stage="Этап 8"
      description="Кто ведёт разборы, курс и эфиры."
    />
  )
}
