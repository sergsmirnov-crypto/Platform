import { PagePlaceholder } from '../../../_components/page-placeholder'

type Props = { params: Promise<{ slug: string }> }

export const metadata = { title: 'Разбор песни' }

export default async function SongPage({ params }: Props) {
  const { slug } = await params

  return (
    <PagePlaceholder
      title="Разбор песни"
      stage="Этап 5"
      description="Уровни, части разбора, видео, табы, заметки."
      values={[{ label: 'slug', value: slug }]}
    />
  )
}
