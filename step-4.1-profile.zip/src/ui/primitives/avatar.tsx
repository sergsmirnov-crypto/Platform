import { User } from 'lucide-react'

import { cn } from '@/ui/lib/cn'

/**
 * Аватар участника.
 *
 * Пока фотография не загружена — нейтральный силуэт, а не первая буква
 * имени и не пустой круг. Буква выглядит как аватар, которого человек
 * не выбирал; пустой круг читается как поломка интерфейса. Силуэт честно
 * означает «фотографии нет».
 *
 * Фотография из Telegram намеренно не подставляется: по решению
 * владельца платформы участник либо загружает снимок сам, либо остаётся
 * без него.
 *
 * Загрузка появится на шаге 4.3, поэтому изображение выводится обычным
 * тегом: настройка разрешённых источников имеет смысл вместе с ней.
 */

type AvatarProps = {
  src?: string | null | undefined
  alt?: string | undefined
  size?: 'sm' | 'md' | 'lg' | undefined
  className?: string | undefined
}

const SIZES = {
  sm: 'h-8 w-8',
  md: 'h-12 w-12',
  lg: 'h-24 w-24',
} as const

const ICON_SIZES = { sm: 16, md: 22, lg: 40 } as const

export function Avatar({ src, alt = '', size = 'md', className }: AvatarProps) {
  const base = cn(
    'bg-surface-hover text-content-subtle flex shrink-0 items-center justify-center overflow-hidden rounded-full',
    SIZES[size],
    className,
  )

  if (!src) {
    return (
      <span className={base} role="img" aria-label={alt || 'Фотография не загружена'}>
        <User size={ICON_SIZES[size]} aria-hidden />
      </span>
    )
  }

  return (
    <span className={base}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={src} alt={alt} className="h-full w-full object-cover" />
    </span>
  )
}
