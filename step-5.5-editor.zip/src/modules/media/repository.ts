import 'server-only'

import { and, eq } from 'drizzle-orm'
import { v7 as uuidv7 } from 'uuid'

import { db } from '@/shared/db'

import { mediaAssets } from './schema'

import type { MediaKind } from './domain'

/**
 * Запросы к реестру файлов.
 *
 * Единственное место модуля, где есть SQL. Наружу отдаётся строка
 * как есть, без превращения в вид для интерфейса: этим занимается
 * сервис, потому что решение «показывать ли ключ хранилища» — вопрос
 * доступа, а не хранения.
 */

/** Файл со всем, что нужно, чтобы решить, отдавать его или нет */
export type StoredAssetRow = {
  id: string
  kind: MediaKind
  provider: 'bunny' | 'kinescope' | 's3' | 'soundslice' | 'external'
  /** Для файлов в своём хранилище здесь лежит ключ объекта */
  externalId: string | null
  url: string | null
  title: string | null
  sizeBytes: number | null
  processingStatus: string
  isDownloadable: boolean
}

export async function findAssetById(assetId: string): Promise<StoredAssetRow | null> {
  const [row] = await db
    .select({
      id: mediaAssets.id,
      kind: mediaAssets.kind,
      provider: mediaAssets.provider,
      externalId: mediaAssets.externalId,
      url: mediaAssets.url,
      title: mediaAssets.title,
      sizeBytes: mediaAssets.sizeBytes,
      processingStatus: mediaAssets.processingStatus,
      isDownloadable: mediaAssets.isDownloadable,
    })
    .from(mediaAssets)
    .where(eq(mediaAssets.id, assetId))
    .limit(1)

  return row ?? null
}

/** Ролик уже заведён? Один и тот же файл не должен размножаться записями */
export async function findVideoAssetByExternalId(externalId: string): Promise<string | null> {
  const [row] = await db
    .select({ id: mediaAssets.id })
    .from(mediaAssets)
    .where(and(eq(mediaAssets.kind, 'video'), eq(mediaAssets.externalId, externalId)))
    .limit(1)

  return row?.id ?? null
}

export async function insertVideoAsset(input: {
  externalId: string
  provider: 'kinescope' | 'external'
  title: string | null
  uploadedBy: string
}): Promise<string> {
  const id = uuidv7()

  await db.insert(mediaAssets).values({
    id,
    kind: 'video',
    provider: input.provider,
    externalId: input.externalId,
    title: input.title,
    // Ролик уже обработан хостингом: мы его не загружали, а только записали
    processingStatus: 'ready',
    // Видео не скачивается никогда — ради этого и выбирается видеохостинг
    isDownloadable: false,
    uploadedBy: input.uploadedBy,
  })

  return id
}
