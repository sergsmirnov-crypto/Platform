import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Разборы' }

export default function SongsCatalogPage() {
  return (
    <PagePlaceholder
      title="Разборы"
      stage="Этап 5"
      description="Каталог песен с фильтрами по уровню, жанру, строю и куратору."
    />
  )
}
