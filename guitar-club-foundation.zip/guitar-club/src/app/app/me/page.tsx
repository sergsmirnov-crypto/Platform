import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Личный кабинет' }

export default function MePage() {
  return (
    <PagePlaceholder
      title="Личный кабинет"
      stage="Этап 4"
      description="Профиль, прогресс, избранное, настройки."
    />
  )
}
