import { redirect } from 'next/navigation'

import type { SessionContext } from '@/modules/identity'
import { getSession } from '@/modules/identity/current-user'
import { getAccessStatus } from '@/modules/subscription'
import type { AccessStatus } from '@/modules/subscription'
import { RETURN_TO_PARAM } from '@/shared/config/constants'
import { AUTH_ENABLED } from '@/shared/config/features'
import { routes } from '@/shared/routes'

/**
 * Проверки доступа к закрытой зоне.
 *
 * Живут в слое приложения, а не в модуле, намеренно. Здесь встречаются три
 * разных модуля — вход, права и подписка — и решается, что показать человеку.
 * Это и есть работа слоя приложения: модули отвечают на вопросы, страницы
 * складывают ответы в поведение.
 *
 * Второе соображение: перенаправление — понятие Next.js. Модули о нём знать
 * не должны, иначе их нельзя будет использовать в фоновых задачах.
 *
 * ⚠️ Это проверка на сервере, а не в middleware. Middleware делает только
 * дешёвый редирект по наличию cookie и границей безопасности не является
 * (ADR-0003, CVE-2025-29927).
 */

/**
 * Требует действующую сессию.
 *
 * Человека без сессии отправляет на вход, запоминая, куда он шёл:
 * после входа он попадёт туда, а не на главную.
 */
export async function requireMember(currentPath: string): Promise<SessionContext | null> {
  // Пока проверка входа выключена, закрытая зона открыта: иначе каркас
  // страниц невозможно посмотреть. В производственной среде это значение
  // обязано быть включено — приложение иначе не запустится.
  if (!AUTH_ENABLED) return null

  const session = await getSession()

  if (!session) {
    const target = new URL(routes.home(), 'http://internal')
    target.searchParams.set(RETURN_TO_PARAM, currentPath)
    redirect(`${target.pathname}${target.search}`)
  }

  return session
}

/**
 * Требует действующую подписку.
 *
 * Вызывается в разметке платных разделов. Человека без подписки уводит
 * на экран продления — но не выкидывает из платформы: профиль, прогресс
 * и страницы клуба остаются ему доступны (PRD v0.1 §2.2).
 */
export async function requireActiveSubscription(userId: string): Promise<AccessStatus> {
  const access = await getAccessStatus(userId)

  if (!access.hasAccess) {
    redirect(routes.app.subscriptionExpired())
  }

  return access
}

/**
 * Состояние доступа без перенаправления.
 *
 * Нужно там, где содержимое показывается всем, но выглядит по-разному:
 * например, каталог разборов открыт, а кнопка просмотра — нет.
 */
export async function getAccessForCurrentUser(): Promise<AccessStatus | null> {
  const session = await getSession()
  if (!session) return null

  return getAccessStatus(session.user.id)
}
