import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Курс' }

export default function CoursePage() {
  return (
    <PagePlaceholder
      title="Курс"
      stage="Этап 6"
      description="Карта модулей с прогрессом прохождения."
    />
  )
}
