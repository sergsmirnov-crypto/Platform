import { describe, expect, it } from 'vitest'

import { isProtectedPath } from './access'

describe('isProtectedPath', () => {
  it('считает закрытой саму главную закрытой зоны', () => {
    expect(isProtectedPath('/app')).toBe(true)
  })

  it('считает закрытыми вложенные адреса', () => {
    expect(isProtectedPath('/app/learn/songs')).toBe(true)
    expect(isProtectedPath('/app/manage/team')).toBe(true)
  })

  it('оставляет открытыми публичные адреса', () => {
    expect(isProtectedPath('/')).toBe(false)
    expect(isProtectedPath('/legal/offer')).toBe(false)
    expect(isProtectedPath('/auth/telegram')).toBe(false)
  })

  it('не путает похожие адреса с закрытой зоной', () => {
    expect(isProtectedPath('/application')).toBe(false)
    expect(isProtectedPath('/appointments/list')).toBe(false)
  })
})
