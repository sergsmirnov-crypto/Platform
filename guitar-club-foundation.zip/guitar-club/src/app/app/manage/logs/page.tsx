import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Журнал действий' }

export default function AuditLogPage() {
  return (
    <PagePlaceholder
      title="Журнал действий"
      stage="Этап 9"
      description="Кто, что и когда изменил."
    />
  )
}
