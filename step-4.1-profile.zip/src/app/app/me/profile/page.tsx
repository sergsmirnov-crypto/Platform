import { findProfile } from '@/modules/identity'
import { getSession } from '@/modules/identity/current-user'
import { Avatar } from '@/ui'

import { PageIntro } from '../../_components/page-intro'
import { ProfileForm } from '../_components/profile-form'

export const metadata = { title: 'Профиль' }

/**
 * Страница профиля.
 *
 * Данные читаются на сервере и отдаются форме готовыми. Загрузка фото
 * появится на шаге 4.3 — до тех пор аватар показывается, но не меняется.
 */
export default async function ProfilePage() {
  const session = await getSession()
  if (!session) return null

  const profile = await findProfile(session.user.id)
  if (!profile) return null

  return (
    <>
      <PageIntro title="Профиль" description="Эти сведения увидят другие участники клуба" />

      <div className="mb-8 flex items-center gap-4">
        <Avatar src={profile.avatarUrl} alt={profile.displayName} size="lg" />
        <p className="text-content-muted text-sm">Загрузка фотографии появится на следующем шаге</p>
      </div>

      <ProfileForm profile={profile} />
    </>
  )
}
