import { ArrowUpRight } from 'lucide-react'

import { getSetting, SETTING_KEYS } from '@/modules/audit'
import type { TelegramChatLink } from '@/modules/audit'

/**
 * Переходы в чаты Telegram.
 *
 * Не «ссылка внизу страницы», а карточки с объяснением, зачем туда идти
 * (PRD v0.1 §7.6). Разница существенная: «Наш чат» открывают из
 * любопытства один раз, «Спросить куратора — отвечают за пару часов»
 * открывают, когда есть вопрос.
 *
 * Ссылки берутся из настроек платформы, а не зашиты в код: сообщество
 * переезжает между чатами, и ради этого не должен требоваться
 * разработчик. Пока настройка не заполнена — блока просто нет.
 */
export async function TelegramBlock() {
  const chats = await getSetting<TelegramChatLink[]>(SETTING_KEYS.telegramChats)

  if (chats.length === 0) return null

  return (
    <section>
      <h2 className="mb-3 text-lg font-bold">Общение клуба</h2>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {chats.map((chat) => (
          <a
            key={chat.url}
            href={chat.url}
            target="_blank"
            rel="noreferrer noopener"
            className="border-border bg-surface-raised hover:border-accent flex min-h-11 flex-col rounded-xl border p-4 transition-colors"
          >
            <span className="flex items-center gap-1.5 font-medium">
              {chat.title}
              <ArrowUpRight size={15} aria-hidden className="text-content-subtle" />
            </span>
            <span className="text-content-muted mt-1 text-sm">{chat.description}</span>
          </a>
        ))}
      </div>
    </section>
  )
}
