import { Settings } from 'lucide-react'
import Link from 'next/link'

import { identityStrings } from '@/modules/identity'
import { signOutAndRedirect } from '@/modules/identity/actions'
import { getSession } from '@/modules/identity/current-user'
import { getAccessStatus, subscriptionStrings } from '@/modules/subscription'
import { routes } from '@/shared/routes'
import { Button } from '@/ui'
import { ThemeToggle } from '@/ui/theme/theme-toggle'

/**
 * Шапка платформы.
 *
 * Держит три вещи: название клуба, состояние подписки и выход.
 * Поиск и уведомления добавятся сюда на Этапе 10 — место под них
 * оставлено намеренно.
 *
 * Серверный компонент: состояние подписки читается из базы, и тащить
 * это в браузер незачем.
 */

const TONE: Record<string, string> = {
  active: 'text-content-muted',
  grace: 'bg-accent text-accent-content',
  expired: 'bg-danger text-danger-content',
  none: 'text-content-subtle',
}

type AppHeaderProps = {
  /** Есть ли у человека доступ к разделу «Управление» */
  canManage: boolean
}

export async function AppHeader({ canManage }: AppHeaderProps) {
  const session = await getSession()
  const access = session ? await getAccessStatus(session.user.id) : null

  return (
    <header className="border-border bg-surface sticky top-0 z-30 border-b">
      <div className="flex h-14 items-center gap-4 px-4 md:px-6">
        <Link href={routes.app.dashboard()} className="text-base font-bold">
          Гитарный клуб
        </Link>

        <div className="ml-auto flex items-center gap-3">
          {access ? (
            <Link
              href={access.hasAccess ? routes.app.me.settings() : routes.app.subscriptionExpired()}
              className={`hidden rounded-full px-3 py-1 text-xs sm:block ${TONE[access.status] ?? ''}`}
            >
              {subscriptionStrings.status[access.status]}
              {access.daysLeft !== null ? ` · ${access.daysLeft} дн.` : ''}
            </Link>
          ) : null}

          {/*
            На телефоне бокового меню нет, поэтому вход в «Управление»
            переезжает в шапку: иначе куратор не смог бы туда попасть
            вообще — а публиковать разборы с телефона он будет.
          */}
          {canManage ? (
            <Link
              href={routes.app.manage.index()}
              aria-label="Управление"
              className="text-content-muted hover:text-content flex h-11 w-11 items-center justify-center md:hidden"
            >
              <Settings size={20} aria-hidden />
            </Link>
          ) : null}

          <ThemeToggle className="hidden md:inline-flex" />

          {session ? (
            <form action={signOutAndRedirect}>
              <Button type="submit" variant="ghost" size="sm">
                {identityStrings.signOut}
              </Button>
            </form>
          ) : null}
        </div>
      </div>
    </header>
  )
}
