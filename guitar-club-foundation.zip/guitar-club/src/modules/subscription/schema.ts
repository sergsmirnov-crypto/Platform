import { bigserial, index, jsonb, pgEnum, pgTable, text, uuid } from 'drizzle-orm/pg-core'

import { users } from '@/modules/identity/schema'
import { createdAt, primaryId, timestampTz, updatedAt } from '@/shared/db/columns'

/**
 * Подписки.
 *
 * Главный принцип из PRD v0.1 §7.1: решение о доступе принимает платформа,
 * а не Telegram. Telegram лишь присылает событие «человек вошёл в канал»
 * или «вышел из него», а состояние доступа хранится здесь.
 *
 * Поэтому при недоступном Telegram платформа продолжает работать:
 * молчание мессенджера никогда не означает «подписка кончилась».
 */

export const entitlementStatusEnum = pgEnum('entitlement_status', [
  'none',
  'active',
  /** Льготный период: доступ ещё есть, но скоро кончится */
  'grace',
  'expired',
])

export const entitlementSourceEnum = pgEnum('entitlement_source', [
  /** Членство в закрытом канале — основной путь сегодня */
  'telegram_channel',
  'telegram_payment',
  /** Выдано вручную администратором */
  'manual',
  'promo',
])

export const verificationStateEnum = pgEnum('verification_state', ['ok', 'stale', 'tg_unreachable'])

export const subscriptionEventTypeEnum = pgEnum('subscription_event_type', [
  'joined',
  'left',
  'kicked',
  'payment_ok',
  'payment_failed',
  'manual_grant',
  'manual_revoke',
  'expired',
  'renewed',
])

export const subscriptionEventSourceEnum = pgEnum('subscription_event_source', [
  'webhook',
  'reconcile',
  'admin',
  'payment',
])

/** Текущее состояние доступа. Одна строка на человека. */
export const entitlements = pgTable('entitlements', {
  id: primaryId(),
  userId: uuid('user_id')
    .notNull()
    .unique()
    .references(() => users.id, { onDelete: 'cascade' }),

  status: entitlementStatusEnum('status').notNull().default('none'),
  source: entitlementSourceEnum('source'),

  validUntil: timestampTz('valid_until'),
  graceUntil: timestampTz('grace_until'),

  /** Когда последний раз сверялись с Telegram */
  lastVerifiedAt: timestampTz('last_verified_at'),
  verificationState: verificationStateEnum('verification_state').notNull().default('ok'),

  meta: jsonb('meta').$type<Record<string, unknown>>().notNull().default({}),

  createdAt: createdAt(),
  updatedAt: updatedAt(),
})

/**
 * Журнал событий подписки. Только добавление, без изменений и удалений.
 *
 * Нужен, чтобы разобрать спорный случай («мне не продлили») и восстановить
 * состояние, если уведомление от Telegram потерялось.
 */
export const subscriptionEvents = pgTable(
  'subscription_events',
  {
    id: bigserial('id', { mode: 'bigint' }).primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    eventType: subscriptionEventTypeEnum('event_type').notNull(),
    source: subscriptionEventSourceEnum('source').notNull(),
    payload: jsonb('payload').$type<Record<string, unknown>>().notNull().default({}),

    occurredAt: timestampTz('occurred_at').notNull().defaultNow(),
  },
  (table) => [index('subscription_events_user_idx').on(table.userId, table.occurredAt)],
)

/**
 * Обработанные уведомления от Telegram.
 *
 * Telegram может прислать одно и то же уведомление дважды. Без этой таблицы
 * повторная доставка приведёт к двойной обработке события.
 */
export const telegramUpdates = pgTable('telegram_updates', {
  updateId: text('update_id').primaryKey(),
  payload: jsonb('payload').$type<Record<string, unknown>>().notNull(),
  processedAt: timestampTz('processed_at'),
  status: text('status').notNull().default('received'),
  error: text('error'),
  createdAt: createdAt(),
})
