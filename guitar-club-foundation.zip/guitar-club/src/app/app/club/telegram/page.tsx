import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Чаты клуба' }

export default function TelegramLinksPage() {
  return (
    <PagePlaceholder
      title="Чаты клуба"
      stage="Этап 8"
      description="Переходы в общий чат, вопросы кураторам, идеи."
    />
  )
}
