import { PagePlaceholder } from '../../_components/page-placeholder'

type Props = { params: Promise<{ slug: string }> }

export const metadata = { title: 'Запись эфира' }

export default async function StreamPage({ params }: Props) {
  const { slug } = await params

  return (
    <PagePlaceholder
      title="Запись эфира"
      stage="Этап 7"
      description="Видео, таймкоды, материалы, упомянутые разборы."
      values={[{ label: 'slug', value: slug }]}
    />
  )
}
