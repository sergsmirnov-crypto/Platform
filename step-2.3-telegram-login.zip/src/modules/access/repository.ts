import 'server-only'

import { eq } from 'drizzle-orm'

import { db } from '@/shared/db'

import { rolePermissions, roles, userPermissions, userRoles } from './schema'

import type { RolePermissionRow, UserPermissionRow } from './effective-permissions'

/**
 * Запросы к базе, связанные с правами.
 *
 * Единственное место в модуле, где есть SQL. Всё остальное работает
 * с уже полученными данными.
 */

/** Права, которые человек получает через свои роли */
export async function findRolePermissions(userId: string): Promise<RolePermissionRow[]> {
  const rows = await db
    .select({
      permissionKey: rolePermissions.permissionKey,
      scope: rolePermissions.scope,
    })
    .from(userRoles)
    .innerJoin(rolePermissions, eq(rolePermissions.roleId, userRoles.roleId))
    .where(eq(userRoles.userId, userId))

  return rows
}

/** Персональные исключения человека */
export async function findUserPermissions(userId: string): Promise<UserPermissionRow[]> {
  const rows = await db
    .select({
      permissionKey: userPermissions.permissionKey,
      effect: userPermissions.effect,
      scope: userPermissions.scope,
    })
    .from(userPermissions)
    .where(eq(userPermissions.userId, userId))

  return rows
}

/** Роль по её коду: 'owner', 'curator' */
export async function findRoleByCode(code: string): Promise<{ id: string } | null> {
  const rows = await db.select({ id: roles.id }).from(roles).where(eq(roles.code, code)).limit(1)

  return rows[0] ?? null
}

/** Есть ли у человека хотя бы одна роль */
export async function countUserRoles(userId: string): Promise<number> {
  const rows = await db
    .select({ roleId: userRoles.roleId })
    .from(userRoles)
    .where(eq(userRoles.userId, userId))

  return rows.length
}

/**
 * Выдаёт роль.
 *
 * Повторный вызов безопасен: связка «человек — роль» уникальна,
 * и попытка выдать уже выданное ничего не меняет.
 */
export async function insertUserRole(
  userId: string,
  roleId: string,
  grantedBy: string | null,
): Promise<void> {
  await db.insert(userRoles).values({ userId, roleId, grantedBy }).onConflictDoNothing()
}
