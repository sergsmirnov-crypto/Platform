/**
 * Публичный вход модуля эфиров.
 *
 * Наружу — чистые правила, типы и тексты. Чтение из базы живёт
 * в `service.ts` с пометкой `server-only`.
 */
export {
  canJoin,
  formatDuration,
  formatTimecode,
  isUpcoming,
  LIVE_GRACE_HOURS,
  streamPhase,
  timeUntil,
} from './domain'
export type { StreamPhase, StreamStateInput } from './domain'

export {
  archiveOffset,
  buildArchiveQuery,
  hasArchiveFilters,
  parseArchiveFilters,
  searchTerms,
} from './archive-filters'
export type { ArchiveFilters, RawSearchParams } from './archive-filters'

export {
  buildCalendarEvent,
  CLUB_TIMEZONE_LABEL,
  formatArchiveDate,
  formatStreamDateTime,
  formatStreamDay,
  formatStreamTime,
  isSameClockAsClub,
} from './schedule'
export type { CalendarEvent } from './schedule'

export type { StreamState } from './schema'

export { streamStrings } from './strings'

export type { StreamCard, StreamChapter, StreamRef, StreamSong, StreamView } from './types'
