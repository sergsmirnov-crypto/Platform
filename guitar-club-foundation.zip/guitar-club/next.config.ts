import type { NextConfig } from 'next'

const nextConfig: NextConfig = {
  // standalone — компактная сборка для Docker: в образ попадает только то,
  // что реально нужно для запуска, без всего node_modules (шаг F10).
  output: 'standalone',

  // Строгий режим React подсвечивает небезопасные приёмы на этапе разработки.
  reactStrictMode: true,

  // Заголовки безопасности. Применяются ко всем страницам.
  // Content-Security-Policy добавим на F6, когда станет известен список
  // внешних источников (видеохостинг, Sentry, PostHog).
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
        ],
      },
    ]
  },
}

export default nextConfig
