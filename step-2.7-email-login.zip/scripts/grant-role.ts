/**
 * Выдача роли участнику из командной строки.
 *
 * Запуск:
 *   pnpm role:grant <почта или telegram_id> <роль>
 *
 * Роли: curator | senior_curator | admin | owner
 *
 * ─────────────────────────────────────────────────────────────────
 * ЗАЧЕМ ЭТА КОМАНДА, ЕСЛИ РОЛИ ВЫДАЮТСЯ В ИНТЕРФЕЙСЕ
 *
 * Обычный путь — «Управление → Команда», и он остаётся основным.
 * Командная строка нужна ровно в двух случаях, и оба реальны:
 *
 * 1. Первый администратор. Раздел «Команда» доступен только тому,
 *    у кого уже есть право `users.roles`. Пока такого человека нет,
 *    выдать права некому — замкнутый круг. Обычно его разрывает
 *    переменная OWNER_EMAIL при первом входе, но она работает только
 *    для человека, у которого ещё нет ни одной роли.
 *
 * 2. Владелец потерял доступ. Роль владельца неотзываема из интерфейса
 *    именно для того, чтобы её нельзя было снять по ошибке, — но если
 *    доступ всё же утрачен, восстановить его должно быть возможно
 *    тому, у кого есть доступ к серверу.
 *
 * Команда намеренно требует почту или Telegram ID, а не имя: имена
 * повторяются, а ошибка здесь выдаёт человеку права на всю платформу.
 * Почта — основной способ входа (ADR-0030); Telegram ID остался для тех,
 * кто входил через Telegram до перехода на почту.
 * ─────────────────────────────────────────────────────────────────
 *
 * Участник должен хотя бы раз войти на платформу — тогда у него есть
 * учётная запись. Исключение: роль владельца можно выдать «наперёд»,
 * учётная запись будет создана.
 */
import { loadEnvFile } from 'node:process'

import { eq, sql } from 'drizzle-orm'
import { v7 as uuidv7 } from 'uuid'

try {
  loadEnvFile('.env')
} catch {
  // На сервере переменные приходят из окружения
}

const { db } = await import('@/shared/db')
const schema = await import('@/shared/db/schema')

const KNOWN_ROLES = ['curator', 'senior_curator', 'admin', 'owner'] as const
type KnownRole = (typeof KNOWN_ROLES)[number]

const [whoArg, roleArg] = process.argv.slice(2)

function fail(message: string): never {
  console.error(`\n${message}\n`)
  console.error('Использование: pnpm role:grant <почта или telegram_id> <роль>')
  console.error(`Роли: ${KNOWN_ROLES.join(' | ')}`)
  console.error('Почта — та, с которой участник входит на платформу.\n')
  process.exit(1)
}

const who = whoArg?.trim().toLowerCase()
const role = roleArg?.trim() as KnownRole | undefined

/** По почте или по Telegram ID: разные строки в таблице способов входа */
const provider = who?.includes('@') ? 'email' : 'telegram'

if (!who || (provider === 'telegram' && !/^\d+$/.test(who))) {
  fail('Укажите почту участника или его Telegram ID (это число, а не @username).')
}

if (!role || !KNOWN_ROLES.includes(role)) {
  fail(`Неизвестная роль: ${roleArg ?? '(не указана)'}`)
}

const [roleRow] = await db
  .select({ id: schema.roles.id, title: schema.roles.title })
  .from(schema.roles)
  .where(eq(schema.roles.code, role))
  .limit(1)

if (!roleRow) {
  fail('Роли в базе не найдены. Сначала выполните: pnpm db:seed')
}

const [identity] = await db
  .select({ userId: schema.authIdentities.userId })
  .from(schema.authIdentities)
  .where(
    sql`${schema.authIdentities.provider} = ${provider}
        AND ${schema.authIdentities.providerUserId} = ${who}`,
  )
  .limit(1)

let userId = identity?.userId

if (!userId) {
  if (role !== 'owner') {
    fail(
      `Участник ${who} не найден.\n` +
        'Он должен хотя бы раз войти на платформу — тогда появится учётная запись.\n' +
        'Создать наперёд можно только владельца.',
    )
  }

  const [created] = await db
    .insert(schema.users)
    .values({ id: uuidv7(), displayName: 'Владелец' })
    .returning({ id: schema.users.id })

  if (!created) fail('Не удалось создать учётную запись.')
  userId = created.id

  await db.insert(schema.authIdentities).values({
    id: uuidv7(),
    userId,
    provider,
    providerUserId: who,
    isPrimary: true,
    verifiedAt: new Date(),
  })

  console.log('Создана учётная запись владельца.')
}

await db.insert(schema.userRoles).values({ userId, roleId: roleRow.id }).onConflictDoNothing()

// Владельцу доступ к содержимому не зависит от подписки: платформу
// нельзя потерять из-за неудачного списания
if (role === 'owner') {
  await db
    .insert(schema.entitlements)
    .values({ id: uuidv7(), userId, status: 'active', source: 'manual' })
    .onConflictDoNothing()
}

const [user] = await db
  .select({ name: schema.users.displayName })
  .from(schema.users)
  .where(eq(schema.users.id, userId))
  .limit(1)

console.log(`Готово: «${user?.name ?? 'участник'}» получил роль «${roleRow.title}».`)
console.log('Изменение вступает в силу при следующем открытии страницы.')

process.exit(0)
