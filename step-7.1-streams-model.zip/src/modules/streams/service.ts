import 'server-only'

import type { ContentViewer } from '@/shared/content'
import { errors } from '@/shared/errors'

import { canJoin, formatTimecode, streamPhase } from './domain'
import {
  findArchive,
  findChapters,
  findStreamBySlug,
  findStreamSongs,
  findStreamsForSong,
  findUpcoming,
} from './repository'

import type { StreamRow } from './repository'
import type { StreamCard, StreamView } from './types'

/**
 * Сборка эфиров для показа.
 *
 * Состояние («скоро», «идёт», «запись») вычисляется здесь, а не хранится
 * в базе: оно зависит от текущего времени, и записанное значение
 * устаревает молча — через час после эфира база по-прежнему утверждала бы,
 * что он идёт.
 *
 * Текущее время передаётся одно на всю страницу. Иначе два эфира
 * в одном списке считались бы по разным часам, и на границе минуты
 * соседние карточки показывали бы «через 1 час» и «через 59 мин».
 */

function toCard(row: StreamRow, now: Date): StreamCard {
  return {
    id: row.id,
    slug: row.slug,
    title: row.title,
    description: row.description,
    startsAt: row.startsAt,
    phase: streamPhase(
      {
        state: row.state,
        startsAt: row.startsAt,
        endedAt: row.endedAt,
        hasVideo: row.videoAssetId !== null,
      },
      now,
    ),
    curatorName: row.curatorName,
    coverUrl: row.coverUrl,
    hasVideo: row.videoAssetId !== null,
    durationSec: row.durationSec,
    isDraft: row.status !== 'published',
  }
}

/** Ближайшие эфиры: анонсы и то, что идёт прямо сейчас */
export async function getUpcomingStreams(viewer: ContentViewer, limit = 5): Promise<StreamCard[]> {
  const now = new Date()
  const rows = await findUpcoming(viewer.canSeeDrafts, limit)

  return rows.map((row) => toCard(row, now))
}

/** Архив записей с постраничной навигацией и поиском */
export async function getStreamArchive(
  viewer: ContentViewer,
  input: { query: string | null; curatorId: string | null; page: number; pageSize: number },
): Promise<{ items: StreamCard[]; total: number; pageCount: number }> {
  const now = new Date()
  const { items, total } = await findArchive({ includeDrafts: viewer.canSeeDrafts, ...input })

  return {
    items: items.map((row) => toCard(row, now)),
    total,
    pageCount: Math.max(1, Math.ceil(total / input.pageSize)),
  }
}

/** Страница эфира со всем содержимым */
export async function getStreamBySlug(viewer: ContentViewer, slug: string): Promise<StreamView> {
  const row = await findStreamBySlug(slug, viewer.canSeeDrafts)
  if (!row) throw errors.notFound('Эфир не найден')

  const now = new Date()
  const card = toCard(row, now)

  const [chapters, songs] = await Promise.all([findChapters(row.id), findStreamSongs(row.id)])

  return {
    ...card,
    videoAssetId: row.videoAssetId,
    joinUrl: row.joinUrl,
    canJoin: canJoin({ joinUrl: row.joinUrl, startsAt: row.startsAt }, card.phase, now),
    // Подпись таймкода считается один раз на сервере: в браузере она
    // не меняется, и пересчитывать её при каждой отрисовке незачем
    chapters: chapters.map((chapter) => ({
      ...chapter,
      timecode: formatTimecode(chapter.startSec),
    })),
    songs,
    endedAt: row.endedAt,
  }
}

/** Эфиры, в которых разбирали эту песню — для страницы разбора */
export async function getStreamsForSong(
  viewer: ContentViewer,
  songId: string,
): Promise<StreamCard[]> {
  const now = new Date()
  const rows = await findStreamsForSong(songId, viewer.canSeeDrafts)

  return rows.map((row) => toCard(row, now))
}
