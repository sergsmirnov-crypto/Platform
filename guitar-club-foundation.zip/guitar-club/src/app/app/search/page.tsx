import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Поиск' }

export default function SearchPage() {
  return (
    <PagePlaceholder
      title="Поиск"
      stage="Этап 10"
      description="Общий поиск по разборам, урокам, эфирам и кураторам."
    />
  )
}
