import { routes } from '@/shared/routes'

import { AppHeader } from './_components/app-header'
import { Sidebar } from './_components/sidebar'
import { TabBar } from './_components/tab-bar'
import { getVisibleManageItems, requireMember } from './_lib/guards'

/**
 * Разметка закрытой зоны.
 *
 * Здесь проходит настоящая граница доступа: разметка выполняется на сервере,
 * имеет доступ к базе и может проверить, что сессия действительно живая.
 * Middleware такой проверки не делает и делать не должен (ADR-0003).
 *
 * Проверка подписки живёт не здесь, а в разметке платных разделов: участник
 * без подписки не теряет профиль, прогресс и страницы клуба — он должен,
 * вернувшись через полгода, увидеть «ты остановился на уроке 7», а не пустоту.
 *
 * Меню строится на сервере уже отфильтрованным по правам: браузер не получает
 * даже названий разделов, которые человеку недоступны.
 */
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  const session = await requireMember(routes.app.dashboard())
  const manageItems = await getVisibleManageItems(session?.user.id ?? null)

  return (
    <div className="bg-surface min-h-dvh">
      <AppHeader canManage={manageItems.length > 0} />

      <div className="flex">
        <Sidebar manageItems={manageItems} />

        {/* Отступ снизу — под мобильную панель, чтобы она не накрывала содержимое */}
        <main className="min-w-0 flex-1 pb-20 md:pb-0">{children}</main>
      </div>

      <TabBar />
    </div>
  )
}
