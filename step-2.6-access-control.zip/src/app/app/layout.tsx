import { routes } from '@/shared/routes'

import { SessionIndicator } from './_components/session-indicator'
import { SubscriptionBadge } from './_components/subscription-badge'
import { TemporaryNav } from './_components/temporary-nav'
import { requireMember } from './_lib/guards'

/**
 * Разметка закрытой зоны.
 *
 * Здесь проходит настоящая граница доступа: разметка выполняется на сервере,
 * имеет доступ к базе и может проверить, что сессия действительно живая.
 * Middleware такой проверки не делает и делать не должен (ADR-0003).
 *
 * Проверка подписки живёт не здесь, а в разметке платных разделов: участник
 * без подписки не теряет профиль, прогресс и страницы клуба — он должен,
 * вернувшись через полгода, увидеть «ты остановился на уроке 7», а не пустоту.
 *
 * На Этапе 3 сюда придут сайдбар, шапка и хлебные крошки.
 */
export default async function AppLayout({ children }: { children: React.ReactNode }) {
  await requireMember(routes.app.dashboard())

  return (
    <div className="min-h-dvh">
      <div className="flex flex-wrap items-center justify-end gap-3 border-b px-6 py-2">
        <SubscriptionBadge />
        <SessionIndicator />
      </div>
      <TemporaryNav />
      {children}
    </div>
  )
}
