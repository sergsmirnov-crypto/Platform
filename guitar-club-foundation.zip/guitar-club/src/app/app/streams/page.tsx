import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Эфиры' }

export default function StreamsPage() {
  return (
    <PagePlaceholder
      title="Эфиры"
      stage="Этап 7"
      description="Архив записей эфиров с таймкодами."
    />
  )
}
