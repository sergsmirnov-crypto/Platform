import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Настройки' }

export default function SettingsPage() {
  return (
    <PagePlaceholder
      title="Настройки"
      stage="Этап 4"
      description="Подписка, уведомления, активные устройства, тема оформления."
    />
  )
}
