import { PagePlaceholder } from '../../../../_components/page-placeholder'

type Props = { params: Promise<{ module: string; lesson: string }> }

export const metadata = { title: 'Урок' }

export default async function LessonPage({ params }: Props) {
  const { module, lesson } = await params

  return (
    <PagePlaceholder
      title="Урок"
      stage="Этап 6"
      description="Видео, текст урока, материалы."
      values={[
        { label: 'module', value: module },
        { label: 'lesson', value: lesson },
      ]}
    />
  )
}
