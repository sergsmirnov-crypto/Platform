import { routes } from './routes'

/**
 * Какие адреса относятся к закрытой зоне.
 *
 * ⚠️ Важно: это НЕ проверка прав доступа, а только подсказка для перенаправления
 * («нет cookie — покажем страницу входа»). Настоящая проверка происходит
 * на сервере при обращении к данным. Причины — в ADR-0003.
 */

const PROTECTED_PREFIX = routes.app.dashboard()

export function isProtectedPath(pathname: string): boolean {
  return pathname === PROTECTED_PREFIX || pathname.startsWith(`${PROTECTED_PREFIX}/`)
}
