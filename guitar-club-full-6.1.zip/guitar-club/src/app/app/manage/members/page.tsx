import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Участники' }

export default function MembersPage() {
  return (
    <PagePlaceholder
      title="Участники"
      stage="Этап 9"
      description="Список участников, профили, история активности."
    />
  )
}
