import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Политика обработки персональных данных' }

export default function PrivacyPage() {
  return (
    <PagePlaceholder
      title="Политика обработки персональных данных"
      stage="Этап 9"
      description="Какие данные хранятся и как их удалить."
    />
  )
}
