/**
 * Демонстрационное содержимое для разработки.
 *
 * Запуск: pnpm db:demo
 *
 * ─────────────────────────────────────────────────────────────────
 * ЗАЧЕМ ЭТО НУЖНО
 *
 * Каталог, фильтры, страница песни и постраничная навигация проверяются
 * только на содержимом. На пустой базе они выглядят одинаково рабочими
 * и одинаково сломанными: пустой список — это и правильный ответ,
 * и симптом неверного запроса.
 *
 * Настоящие разборы приедут из Telegram отдельным переносом (PRD v0.2 §3).
 * Здесь — восемь песен, подобранных так, чтобы задеть все случаи:
 * несколько уровней у одной песни и один у другой, два разбора одного
 * уровня от разных кураторов, черновик, запланированная публикация,
 * песня без вариантов вовсе, кириллица и латиница в названиях,
 * разные строи.
 *
 * Видео и файлы не создаются: их место займут настоящие на шаге 5.4.
 * Части разбора при этом размечены таймкодами — так проверяется
 * подсчёт длительности.
 * ─────────────────────────────────────────────────────────────────
 *
 * Команду можно запускать повторно: демо-песни определяются по адресу
 * и пересоздаются целиком. Ничего, кроме них, скрипт не трогает.
 */
import { loadEnvFile } from 'node:process'

import { inArray } from 'drizzle-orm'
import { drizzle } from 'drizzle-orm/postgres-js'
import postgres from 'postgres'
import { v7 as uuidv7 } from 'uuid'

import { songSlug } from '../src/modules/songs/domain'
import { TAG_SEEDS } from '../src/modules/taxonomy/catalog'
import * as schema from '../src/shared/db/schema'

try {
  loadEnvFile('.env')
} catch {
  // На боевом сервере переменные приходят из окружения
}

if (process.env.NODE_ENV === 'production') {
  console.error('Демонстрационное содержимое в производственной среде не создаётся.')
  process.exit(1)
}

const url = process.env.DATABASE_URL
if (!url) {
  console.error('Не задано подключение к базе данных (DATABASE_URL).')
  process.exit(1)
}

const client = postgres(url, { max: 1, onnotice: () => {} })
const db = drizzle(client, { schema })

type DemoSection = { title: string; start: number; end: number }

type DemoArrangement = {
  level: 'beginner' | 'intermediate' | 'advanced'
  title?: string
  summary: string
  estimatedMinutes: number
  status?: 'draft' | 'published'
  sections: DemoSection[]
}

type DemoSong = {
  title: string
  artist: string
  album?: string
  year?: number
  tuning?: string
  capo?: number
  tempoBpm?: number
  musicKey?: string
  description: string
  status?: 'draft' | 'scheduled' | 'published'
  publishedAt?: Date
  tags: string[]
  arrangements: DemoArrangement[]
}

/** Обычная структура: шесть частей подряд, с реальными таймкодами */
function standardSections(): DemoSection[] {
  return [
    { title: 'Вступление', start: 0, end: 134 },
    { title: 'Куплет', start: 134, end: 319 },
    { title: 'Припев', start: 319, end: 479 },
    { title: 'Проигрыш', start: 479, end: 594 },
    { title: 'Соло', start: 594, end: 974 },
    { title: 'Сборка целиком', start: 974, end: 1224 },
  ]
}

function simpleSections(): DemoSection[] {
  return [
    { title: 'Вступление', start: 0, end: 95 },
    { title: 'Основная часть', start: 95, end: 340 },
    { title: 'Сборка целиком', start: 340, end: 520 },
  ]
}

const DAY = 24 * 60 * 60 * 1000
const daysAgo = (days: number) => new Date(Date.now() - days * DAY)
const daysAhead = (days: number) => new Date(Date.now() + days * DAY)

const DEMO_SONGS: DemoSong[] = [
  {
    title: 'Nothing Else Matters',
    artist: 'Metallica',
    album: 'Metallica',
    year: 1991,
    tuning: 'e_standard',
    tempoBpm: 72,
    musicKey: 'Em',
    description:
      'Песня, с которой начинают почти все. Разбираем перебор во вступлении, ' +
      'аккорды в куплете и подводим к соло.',
    publishedAt: daysAgo(2),
    tags: ['Метал', 'Перебор', 'Соло'],
    arrangements: [
      {
        level: 'beginner',
        title: 'Акустика, упрощённо',
        summary: 'Четыре аккорда и простой перебор. Первая песня, которую можно доиграть до конца.',
        estimatedMinutes: 40,
        sections: simpleSections(),
      },
      {
        level: 'intermediate',
        title: 'Акустика, как в оригинале',
        summary: 'Полный перебор вступления, переходы и проигрыш.',
        estimatedMinutes: 90,
        sections: standardSections(),
      },
      {
        level: 'advanced',
        title: 'Электро, с соло',
        summary: 'Соло целиком, с разбором фразировки и подтяжек.',
        estimatedMinutes: 180,
        sections: standardSections(),
      },
    ],
  },
  {
    title: 'Пачка сигарет',
    artist: 'Кино',
    album: 'Звезда по имени Солнце',
    year: 1989,
    tuning: 'e_standard',
    capo: 2,
    tempoBpm: 118,
    musicKey: 'Am',
    description: 'Четыре аккорда, бой и узнаваемая мелодия. Классика двора и костра.',
    publishedAt: daysAgo(6),
    tags: ['Русский рок', 'Бой', 'У костра'],
    arrangements: [
      {
        level: 'beginner',
        summary: 'Простой бой и четыре аккорда с каподастром на втором ладу.',
        estimatedMinutes: 30,
        sections: simpleSections(),
      },
      {
        level: 'intermediate',
        title: 'С проигрышем на одной струне',
        summary: 'Добавляем мелодическую линию и глушение.',
        estimatedMinutes: 60,
        sections: standardSections(),
      },
    ],
  },
  {
    title: 'Перемен',
    artist: 'Кино',
    year: 1989,
    tuning: 'e_standard',
    tempoBpm: 128,
    musicKey: 'Am',
    description: 'Разбираем бой с акцентами и переходы между частями.',
    publishedAt: daysAgo(11),
    tags: ['Русский рок', 'Бой'],
    arrangements: [
      {
        level: 'beginner',
        summary: 'Аккорды и ровный бой.',
        estimatedMinutes: 35,
        sections: simpleSections(),
      },
    ],
  },
  {
    title: 'Blackbird',
    artist: 'The Beatles',
    album: 'The White Album',
    year: 1968,
    tuning: 'e_standard',
    tempoBpm: 96,
    musicKey: 'G',
    description:
      'Фингерстайл, с которого удобно начинать: мелодия и бас играются одновременно, ' +
      'но темп прощает ошибки.',
    publishedAt: daysAgo(20),
    tags: ['Классический рок', 'Фингерстайл'],
    arrangements: [
      {
        level: 'intermediate',
        title: 'Вариант Ивана',
        summary: 'Разбор по фразам, с отдельным вниманием к независимости пальцев.',
        estimatedMinutes: 120,
        sections: standardSections(),
      },
      {
        // Два разбора одного уровня от разных кураторов — то, ради чего
        // варианты вынесены в отдельную таблицу
        level: 'intermediate',
        title: 'Вариант Марии, с упрощённым басом',
        summary: 'Тот же уровень, но бас сведён к основным долям.',
        estimatedMinutes: 90,
        sections: simpleSections(),
      },
    ],
  },
  {
    title: 'Hotel California',
    artist: 'Eagles',
    album: 'Hotel California',
    year: 1976,
    tuning: 'e_standard',
    capo: 7,
    tempoBpm: 74,
    musicKey: 'Bm',
    description: 'Аккомпанемент, арпеджио и подход к двойному соло.',
    publishedAt: daysAgo(30),
    tags: ['Классический рок', 'Соло', 'Медиатор'],
    arrangements: [
      {
        level: 'advanced',
        summary: 'Полный разбор, включая гармонизованное соло.',
        estimatedMinutes: 240,
        sections: standardSections(),
      },
    ],
  },
  {
    title: 'Кукушка',
    artist: 'Кино',
    year: 1990,
    tuning: 'drop_d',
    tempoBpm: 104,
    musicKey: 'Dm',
    description: 'Разбираем в пониженном строе — так звучит ближе к оригиналу.',
    publishedAt: daysAgo(45),
    tags: ['Русский рок', 'Бой', 'Грустное'],
    arrangements: [
      {
        level: 'beginner',
        summary: 'Строй Drop D, три аккорда, ровный бой.',
        estimatedMinutes: 45,
        sections: simpleSections(),
      },
      {
        level: 'advanced',
        title: 'С мелодической линией',
        summary: 'Добавляем сольные вставки между куплетами.',
        estimatedMinutes: 150,
        sections: standardSections(),
      },
    ],
  },
  {
    // Черновик: виден только куратору. Проверяет, что участник его не видит
    title: 'Stairway to Heaven',
    artist: 'Led Zeppelin',
    album: 'Led Zeppelin IV',
    year: 1971,
    tuning: 'e_standard',
    tempoBpm: 82,
    musicKey: 'Am',
    description: 'Разбор в работе: вступление готово, соло записывается.',
    status: 'draft',
    tags: ['Классический рок', 'Фингерстайл', 'Соло'],
    arrangements: [
      {
        level: 'advanced',
        summary: 'Вступление, аккомпанемент, соло.',
        estimatedMinutes: 300,
        status: 'draft',
        sections: standardSections(),
      },
    ],
  },
  {
    // Запланированная публикация: открывается сама, по времени
    title: 'Wish You Were Here',
    artist: 'Pink Floyd',
    year: 1975,
    tuning: 'e_standard',
    tempoBpm: 60,
    musicKey: 'G',
    description: 'Выйдет на следующей неделе: вступление, аккорды, соло на акустике.',
    status: 'scheduled',
    publishedAt: daysAhead(5),
    tags: ['Классический рок', 'Перебор', 'Спокойное'],
    arrangements: [
      {
        level: 'intermediate',
        summary: 'Вступление с характерным «радиоприёмником» и аккомпанемент.',
        estimatedMinutes: 80,
        sections: standardSections(),
      },
    ],
  },
  {
    // Песня без вариантов: проверяет, что каталог и страница не падают
    title: 'Всё идёт по плану',
    artist: 'Гражданская оборона',
    year: 1988,
    tuning: 'e_standard',
    tempoBpm: 148,
    musicKey: 'Em',
    description: 'Заявка из чата. Разбор ещё не записан.',
    publishedAt: daysAgo(1),
    tags: ['Панк', 'Русский рок'],
    arrangements: [],
  },
]

async function ensureTags(): Promise<Map<string, string>> {
  for (const tag of TAG_SEEDS) {
    await db
      .insert(schema.tags)
      .values({
        id: uuidv7(),
        slug: tag.slug,
        name: tag.name,
        kind: tag.kind,
        orderIndex: tag.orderIndex,
      })
      .onConflictDoUpdate({
        target: schema.tags.slug,
        set: { name: tag.name, kind: tag.kind, orderIndex: tag.orderIndex },
      })
  }

  const rows = await db.select({ id: schema.tags.id, name: schema.tags.name }).from(schema.tags)
  const byName = new Map<string, string>()

  // Имя может встретиться дважды («Фингерстайл» — и жанр, и техника).
  // Для демо-данных достаточно первого совпадения
  for (const row of rows) {
    if (!byName.has(row.name)) byName.set(row.name, row.id)
  }

  console.log(`  метки: ${TAG_SEEDS.length}`)
  return byName
}

/** Кураторы для демо-разборов: берём тех, кто уже есть в базе */
async function findCurators(): Promise<string[]> {
  const rows = await db
    .select({ id: schema.users.id })
    .from(schema.users)
    .orderBy(schema.users.createdAt)
    .limit(3)

  return rows.map((row) => row.id)
}

async function seedSongs(tagIds: Map<string, string>, curators: string[]): Promise<void> {
  const slugs = DEMO_SONGS.map((song) => songSlug(song.artist, song.title))

  // Пересоздаём целиком: связанные записи уйдут каскадом
  const existing = await db
    .select({ id: schema.songs.id })
    .from(schema.songs)
    .where(inArray(schema.songs.slug, slugs))

  if (existing.length > 0) {
    const ids = existing.map((row) => row.id)
    await db.delete(schema.taggables).where(inArray(schema.taggables.entityId, ids))
    await db.delete(schema.songs).where(inArray(schema.songs.id, ids))
    console.log(`  прежние демо-разборы удалены: ${existing.length}`)
  }

  for (const [index, song] of DEMO_SONGS.entries()) {
    const songId = uuidv7()
    const status = song.status ?? 'published'

    await db.insert(schema.songs).values({
      id: songId,
      slug: songSlug(song.artist, song.title),
      title: song.title,
      artist: song.artist,
      album: song.album ?? null,
      year: song.year ?? null,
      description: song.description,
      tuning: song.tuning ?? null,
      capo: song.capo ?? null,
      tempoBpm: song.tempoBpm ?? null,
      musicKey: song.musicKey ?? null,
      status,
      publishedAt: song.publishedAt ?? null,
      popularityScore: (DEMO_SONGS.length - index) * 10,
      createdBy: curators[0] ?? null,
    })

    for (const name of song.tags) {
      const tagId = tagIds.get(name)
      if (!tagId) continue

      await db
        .insert(schema.taggables)
        .values({ tagId, entityType: 'song', entityId: songId })
        .onConflictDoNothing()
    }

    for (const [order, arrangement] of song.arrangements.entries()) {
      const arrangementId = uuidv7()

      await db.insert(schema.arrangements).values({
        id: arrangementId,
        songId,
        level: arrangement.level,
        title: arrangement.title ?? null,
        // Кураторы по кругу: так на странице видно, что разборы разные
        curatorId: curators[order % Math.max(1, curators.length)] ?? null,
        summary: arrangement.summary,
        estimatedMinutes: arrangement.estimatedMinutes,
        orderIndex: order,
        status: arrangement.status ?? 'published',
      })

      await db.insert(schema.arrangementSections).values(
        arrangement.sections.map((section, sectionOrder) => ({
          id: uuidv7(),
          arrangementId,
          title: section.title,
          orderIndex: sectionOrder,
          videoStartSec: section.start,
          videoEndSec: section.end,
        })),
      )
    }
  }

  const total = DEMO_SONGS.reduce((sum, song) => sum + song.arrangements.length, 0)
  console.log(`  разборы: ${DEMO_SONGS.length} песен, ${total} вариантов`)
}

try {
  console.log('Создаю демонстрационное содержимое…')

  const curators = await findCurators()
  if (curators.length === 0) {
    console.log('  ⚠️  в базе нет участников — разборы останутся без кураторов')
    console.log('     сначала выполните pnpm db:seed с заданным OWNER_TELEGRAM_ID')
  }

  const tagIds = await ensureTags()
  await seedSongs(tagIds, curators)

  console.log('Готово. Каталог: /app/learn/songs')
} catch (error) {
  console.error('\nНе удалось создать демонстрационное содержимое.')
  console.error(error instanceof Error ? error.message : error)
  process.exit(1)
} finally {
  await client.end()
}
