/**
 * Публичный вход модуля эфиров.
 *
 * Наружу — чистые правила, типы и тексты. Чтение из базы живёт
 * в `service.ts` с пометкой `server-only`.
 */
export {
  canJoin,
  formatDuration,
  formatTimecode,
  isUpcoming,
  streamPhase,
  timeUntil,
} from './domain'
export type { StreamPhase, StreamStateInput } from './domain'

export type { StreamState } from './schema'

export { streamStrings } from './strings'

export type { StreamCard, StreamChapter, StreamSong, StreamView } from './types'
