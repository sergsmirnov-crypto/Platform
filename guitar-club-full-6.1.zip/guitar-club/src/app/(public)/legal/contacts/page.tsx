import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Контакты' }

export default function ContactsPage() {
  return <PagePlaceholder title="Контакты" stage="Этап 9" description="Как связаться с клубом." />
}
