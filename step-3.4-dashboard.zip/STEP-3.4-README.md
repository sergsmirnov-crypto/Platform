# Шаг 3.4 — Главная страница

Завершает этап 3.

## Применение

```bash
unzip -o step-3.4-dashboard.zip -d /путь/к/guitar-club
cd /путь/к/guitar-club
pnpm db:seed     # добавит ссылки на чаты по умолчанию
pnpm check && pnpm build
```

Новых зависимостей нет, миграции базы не нужны — таблица `app_settings`
существует с этапа 1. Удалять ничего не нужно.
Ожидается: **176 тестов**, ошибок нет, сборка успешна.

> ⚠️ Архивы 3.2 и 3.3 должны быть применены раньше.

## Что проверить в браузере

```bash
docker compose up -d && pnpm db:migrate && pnpm db:seed && pnpm dev
```

| Где                                     | Ожидание                                                        |
| --------------------------------------- | ----------------------------------------------------------------- |
| `/app`                                  | Приветствие по имени и времени суток, без хлебных крошек          |
| Там же                                  | Три карточки чатов Telegram и блок «Платформа наполняется»        |
| Там же, под владельцем                  | Карточки подписки нет — доступ выдан вручную и бессрочно          |
| Отозвать доступ и обновить              | Появляется карточка «Подписка закончилась»                        |
| Телефонная ширина                       | Блоки в одну колонку, ничего не обрезано                          |
| Тёмная тема                             | Карточки читаемы, границы видны                                   |

Ссылки на чаты в сиде — заглушки `https://t.me/`. Настоящие подставьте
в таблице `app_settings`, ключ `telegram.chats`; экран редактирования
появится на этапе 9.

## Состав

**Новые файлы**

```
src/modules/audit/settings.catalog.ts    ключи настроек и значения по умолчанию
src/modules/audit/settings.service.ts    чтение и запись настроек
src/app/app/_lib/greeting.ts             приветствие по времени клуба
src/app/app/_lib/greeting.test.ts        5 тестов
src/app/app/_components/dashboard/greeting-block.tsx
src/app/app/_components/dashboard/subscription-block.tsx
src/app/app/_components/dashboard/telegram-block.tsx
src/app/app/_components/dashboard/coming-soon-block.tsx
```

**Изменённые файлы**

```
src/app/app/page.tsx              главная собрана из блоков
src/modules/audit/index.ts        экспорт настроек
src/shared/config/app.config.ts   часовой пояс клуба
scripts/db-seed.ts                ссылки на чаты по умолчанию
docs/CHANGELOG.md, ROADMAP.md, DECISIONS.md
```

**Коммит**

```
feat(dashboard): add block-based home page and platform settings
```
