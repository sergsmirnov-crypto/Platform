import 'server-only'

import { and, desc, eq, gt, inArray, isNull, lt, ne, or } from 'drizzle-orm'
import { v7 as uuidv7 } from 'uuid'

import { db } from '@/shared/db'

import { avatarUrlFor } from './avatar-url'
import { authIdentities, sessions, users } from './schema'

import type { UserProfile } from './profile'
import type { SessionForLimit } from './session-policy'
import type { SessionUser } from './types'

/**
 * Запросы к базе, связанные с людьми и сессиями.
 *
 * Единственное место в модуле, где есть SQL. Сервис работает с уже
 * полученными данными и ничего не знает о таблицах — благодаря этому
 * логику можно менять, не трогая запросы, и наоборот.
 */

/** Сессия вместе с человеком, которому она принадлежит: один запрос вместо двух */
export type SessionWithUser = {
  id: string
  userId: string
  createdAt: Date
  lastUsedAt: Date
  expiresAt: Date
  revokedAt: Date | null
  user: SessionUser
}

export async function findSessionByTokenHash(tokenHash: string): Promise<SessionWithUser | null> {
  const rows = await db
    .select({
      id: sessions.id,
      userId: sessions.userId,
      createdAt: sessions.createdAt,
      lastUsedAt: sessions.lastUsedAt,
      expiresAt: sessions.expiresAt,
      revokedAt: sessions.revokedAt,
      userDisplayName: users.displayName,
      userAvatarId: users.avatarId,
      userOnboardingDoneAt: users.onboardingDoneAt,
      userDeletedAt: users.deletedAt,
    })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(eq(sessions.tokenHash, tokenHash))
    .limit(1)

  const row = rows[0]
  if (!row) return null

  // Удалённый участник не должен входить по старой сессии
  if (row.userDeletedAt !== null) return null

  return {
    id: row.id,
    userId: row.userId,
    createdAt: row.createdAt,
    lastUsedAt: row.lastUsedAt,
    expiresAt: row.expiresAt,
    revokedAt: row.revokedAt,
    user: {
      id: row.userId,
      displayName: row.userDisplayName,
      avatarUrl: avatarUrlFor(row.userId, row.userAvatarId, 'sm'),
      onboardingDoneAt: row.userOnboardingDoneAt,
    },
  }
}

export type CreateSessionInput = {
  userId: string
  tokenHash: string
  expiresAt: Date
  userAgent: string | null
  ipHash: string | null
}

export async function insertSession(input: CreateSessionInput): Promise<string> {
  const id = uuidv7()

  await db.insert(sessions).values({
    id,
    userId: input.userId,
    tokenHash: input.tokenHash,
    expiresAt: input.expiresAt,
    userAgent: input.userAgent,
    ipHash: input.ipHash,
  })

  return id
}

/** Продлевает срок сессии и отмечает момент последнего использования */
export async function touchSession(sessionId: string, expiresAt: Date): Promise<void> {
  await db
    .update(sessions)
    .set({ lastUsedAt: new Date(), expiresAt })
    .where(eq(sessions.id, sessionId))
}

/** Действующие сессии человека — для списка устройств и проверки лимита */
export async function findActiveSessions(userId: string): Promise<SessionForLimit[]> {
  const rows = await db
    .select({ id: sessions.id, lastUsedAt: sessions.lastUsedAt })
    .from(sessions)
    .where(
      and(
        eq(sessions.userId, userId),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(sessions.lastUsedAt))

  return rows
}

/** Подробности о действующих сессиях — для экрана настроек */
export async function findActiveSessionDetails(userId: string) {
  return db
    .select({
      id: sessions.id,
      userAgent: sessions.userAgent,
      createdAt: sessions.createdAt,
      lastUsedAt: sessions.lastUsedAt,
      expiresAt: sessions.expiresAt,
    })
    .from(sessions)
    .where(
      and(
        eq(sessions.userId, userId),
        isNull(sessions.revokedAt),
        gt(sessions.expiresAt, new Date()),
      ),
    )
    .orderBy(desc(sessions.lastUsedAt))
}

/**
 * Закрывает сессии.
 *
 * Записи не удаляются, а помечаются отозванными: так в журнале остаётся след
 * того, что вход был, и можно разобрать спорный случай.
 */
export async function revokeSessions(sessionIds: readonly string[]): Promise<void> {
  if (sessionIds.length === 0) return

  await db
    .update(sessions)
    .set({ revokedAt: new Date() })
    .where(and(inArray(sessions.id, [...sessionIds]), isNull(sessions.revokedAt)))
}

/** Закрывает все сессии человека. Используется при снятии доступа */
export async function revokeAllSessions(userId: string, exceptSessionId?: string): Promise<void> {
  const conditions = [eq(sessions.userId, userId), isNull(sessions.revokedAt)]

  // «Выйти на всех остальных устройствах»: текущая сессия остаётся живой
  if (exceptSessionId) {
    conditions.push(ne(sessions.id, exceptSessionId))
  }

  await db
    .update(sessions)
    .set({ revokedAt: new Date() })
    .where(and(...conditions))
}

/**
 * Убирает из базы давно закрытые и просроченные сессии.
 *
 * Запускается фоновой задачей. Без уборки таблица растёт вечно:
 * за год у 250 участников накопятся десятки тысяч мёртвых записей.
 */
export async function deleteStaleSessions(before: Date): Promise<number> {
  const removed = await db
    .delete(sessions)
    .where(or(lt(sessions.expiresAt, before), lt(sessions.revokedAt, before)))
    .returning({ id: sessions.id })

  return removed.length
}

/** Человек по идентификатору. Удалённые не возвращаются */
export async function findUserById(userId: string): Promise<SessionUser | null> {
  const rows = await db
    .select({
      id: users.id,
      displayName: users.displayName,
      avatarId: users.avatarId,
      onboardingDoneAt: users.onboardingDoneAt,
    })
    .from(users)
    .where(and(eq(users.id, userId), isNull(users.deletedAt)))
    .limit(1)

  const row = rows[0]
  if (!row) return null

  return { ...row, avatarUrl: avatarUrlFor(row.id, row.avatarId, 'sm') }
}

/** Отмечает, что человек заходил. Используется для статистики активности */
export async function touchUserLastSeen(userId: string): Promise<void> {
  await db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, userId))
}

/**
 * Все участники — только для служебного входа при разработке.
 * В производственной сборке эта функция не вызывается.
 */
export async function findAllUsersForDevelopment(): Promise<SessionUser[]> {
  const rows = await db
    .select({
      id: users.id,
      displayName: users.displayName,
      avatarId: users.avatarId,
      onboardingDoneAt: users.onboardingDoneAt,
    })
    .from(users)
    .where(isNull(users.deletedAt))
    .orderBy(users.createdAt)
    .limit(50)

  return rows.map((row) => ({ ...row, avatarUrl: avatarUrlFor(row.id, row.avatarId, 'sm') }))
}

/** Способ входа вместе с человеком, которому он принадлежит */
export type IdentityWithUser = { userId: string; user: SessionUser }

/** Ищет человека по его идентификатору в Telegram */
export async function findUserByTelegramId(telegramId: string): Promise<IdentityWithUser | null> {
  const rows = await db
    .select({
      userId: users.id,
      displayName: users.displayName,
      avatarId: users.avatarId,
      onboardingDoneAt: users.onboardingDoneAt,
      deletedAt: users.deletedAt,
    })
    .from(authIdentities)
    .innerJoin(users, eq(users.id, authIdentities.userId))
    .where(
      and(eq(authIdentities.provider, 'telegram'), eq(authIdentities.providerUserId, telegramId)),
    )
    .limit(1)

  const row = rows[0]
  if (!row || row.deletedAt !== null) return null

  return {
    userId: row.userId,
    user: {
      id: row.userId,
      displayName: row.displayName,
      avatarUrl: avatarUrlFor(row.userId, row.avatarId, 'sm'),
      onboardingDoneAt: row.onboardingDoneAt,
    },
  }
}

/**
 * Сведения о человеке из Telegram.
 *
 * Фотографии здесь нет намеренно. Ссылка на снимок из Telegram живёт
 * на их серверах: она протухает, а при недоступности мессенджера
 * перестаёт открываться — ровно вопреки главному принципу платформы
 * (ARCHITECTURE §1). Фотографию участник загружает сам; исходная ссылка
 * остаётся в `providerData` как справочные сведения для поддержки.
 */
export type TelegramProfile = {
  telegramId: string
  displayName: string
  /** Всё, что прислал Telegram: имя пользователя, фамилия, ссылка на фото */
  providerData: Record<string, unknown>
}

/**
 * Создаёт участника вместе со способом входа.
 *
 * Обе записи создаются в одной транзакции: человек без способа войти
 * или способ входа без человека — это сломанное состояние, которое
 * потом придётся чинить руками.
 */
export async function createUserWithTelegramIdentity(
  profile: TelegramProfile,
): Promise<IdentityWithUser> {
  const userId = uuidv7()

  await db.transaction(async (tx) => {
    await tx.insert(users).values({
      id: userId,
      displayName: profile.displayName,
      lastSeenAt: new Date(),
    })

    await tx.insert(authIdentities).values({
      id: uuidv7(),
      userId,
      provider: 'telegram',
      providerUserId: profile.telegramId,
      providerData: profile.providerData,
      isPrimary: true,
      verifiedAt: new Date(),
    })
  })

  return {
    userId,
    user: {
      id: userId,
      displayName: profile.displayName,
      avatarUrl: null,
      onboardingDoneAt: null,
    },
  }
}

/**
 * Обновляет сведения, пришедшие от Telegram.
 *
 * Имя и фотография участника платформы НЕ перезаписываются: человек мог
 * поменять их у нас осознанно, и затирать это при каждом входе неправильно.
 * Обновляется только копия данных поставщика — она нужна для поддержки
 * и для поиска участника по имени пользователя в Telegram.
 */
export async function updateTelegramIdentityData(
  telegramId: string,
  providerData: Record<string, unknown>,
): Promise<void> {
  await db
    .update(authIdentities)
    .set({ providerData, updatedAt: new Date() })
    .where(
      and(eq(authIdentities.provider, 'telegram'), eq(authIdentities.providerUserId, telegramId)),
    )
}

/** Идентификатор Telegram по идентификатору участника. Нужен для сверки подписок */
export async function findTelegramIdByUserId(userId: string): Promise<string | null> {
  const rows = await db
    .select({ providerUserId: authIdentities.providerUserId })
    .from(authIdentities)
    .where(and(eq(authIdentities.userId, userId), eq(authIdentities.provider, 'telegram')))
    .limit(1)

  return rows[0]?.providerUserId ?? null
}

export async function findProfile(userId: string): Promise<UserProfile | null> {
  const [row] = await db
    .select({
      id: users.id,
      displayName: users.displayName,
      avatarId: users.avatarId,
      city: users.city,
      bio: users.bio,
      playingSince: users.playingSince,
      skillLevel: users.skillLevel,
      favoriteArtists: users.favoriteArtists,
      favoriteGenres: users.favoriteGenres,
      socials: users.socials,
    })
    .from(users)
    .where(and(eq(users.id, userId), isNull(users.deletedAt)))
    .limit(1)

  if (!row) return null

  // Своя страница показывает фотографию крупно, поэтому здесь берётся
  // большой размер, а не тот, что нужен шапке
  const { avatarId, ...profile } = row

  return { ...profile, avatarUrl: avatarUrlFor(row.id, avatarId, 'lg') }
}

/** Какая фотография сейчас у участника. Нужно, чтобы убрать прежние файлы */
export async function findAvatarId(userId: string): Promise<string | null> {
  const rows = await db
    .select({ avatarId: users.avatarId })
    .from(users)
    .where(and(eq(users.id, userId), isNull(users.deletedAt)))
    .limit(1)

  return rows[0]?.avatarId ?? null
}

/** Записывает новую фотографию или убирает её (`null`) */
export async function updateAvatarId(userId: string, avatarId: string | null): Promise<void> {
  await db
    .update(users)
    .set({
      avatarId,
      avatarUpdatedAt: avatarId ? new Date() : null,
      updatedAt: new Date(),
    })
    .where(eq(users.id, userId))
}

export async function updateProfile(
  userId: string,
  data: Omit<UserProfile, 'id' | 'avatarUrl'>,
): Promise<void> {
  await db
    .update(users)
    .set({
      displayName: data.displayName,
      city: data.city,
      bio: data.bio,
      playingSince: data.playingSince,
      skillLevel: data.skillLevel,
      favoriteArtists: data.favoriteArtists,
      favoriteGenres: data.favoriteGenres,
      socials: data.socials,
      updatedAt: new Date(),
    })
    .where(eq(users.id, userId))
}

/**
 * Обезличивает участника и помечает его удалённым.
 *
 * ─────────────────────────────────────────────────────────────────
 * ПОЧЕМУ НЕ `DELETE FROM users`
 *
 * На запись участника ссылаются журнал действий, история подписки,
 * а позже — прогресс и заметки. Физическое удаление либо разрушило бы
 * эти связи, либо потребовало бы удалить вместе с человеком всю историю
 * платформы, включая записи о действиях других людей.
 *
 * Но и «пометить удалённым, оставив всё как было» неприемлемо: это
 * не удаление, а сокрытие, и требованию об удалении персональных данных
 * оно не отвечает.
 *
 * Поэтому здесь и то и другое: личные сведения затираются по-настоящему,
 * а строка остаётся якорем для связей. Восстановить по ней человека
 * нельзя — способ входа удаляется отдельным запросом рядом.
 * ─────────────────────────────────────────────────────────────────
 */
export async function anonymizeUser(userId: string, displayName: string): Promise<void> {
  await db
    .update(users)
    .set({
      displayName,
      avatarId: null,
      avatarUpdatedAt: null,
      city: null,
      bio: null,
      playingSince: null,
      skillLevel: null,
      socials: {},
      goals: [],
      favoriteArtists: [],
      favoriteGenres: [],
      settings: {},
      deletedAt: new Date(),
      updatedAt: new Date(),
    })
    .where(eq(users.id, userId))
}

/**
 * Убирает все способы входа.
 *
 * После этого войти под прежним аккаунтом невозможно, а идентификатор
 * Telegram освобождается: вернувшись в клуб, человек получит чистый
 * новый аккаунт, а не воскресший старый.
 */
export async function deleteAuthIdentities(userId: string): Promise<void> {
  await db.delete(authIdentities).where(eq(authIdentities.userId, userId))
}
