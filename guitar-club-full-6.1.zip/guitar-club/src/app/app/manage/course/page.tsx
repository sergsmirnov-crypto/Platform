import { PagePlaceholder } from '../../_components/page-placeholder'

export const metadata = { title: 'Курс: управление' }

export default function ManageCoursePage() {
  return (
    <PagePlaceholder
      title="Курс: управление"
      stage="Этап 6"
      description="Дерево модулей и уроков."
    />
  )
}
