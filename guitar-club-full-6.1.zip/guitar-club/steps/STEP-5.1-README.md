# Шаг 5.1 — Модель данных разборов

## Применение

```bash
unzip -o step-5.1-songs-model.zip -d /путь/к/guitar-club
cd /путь/к/guitar-club
pnpm db:migrate     # ⚠️ обязательно: миграция 0004
pnpm check && pnpm build
```

Новых зависимостей нет.
Ожидается: **352 теста**, ошибок нет, сборка успешна.

> ⚠️ Архив 4.4 должен быть применён раньше.

## Что это за шаг

Экранов здесь нет — это фундамент под остальные пять шагов Этапа 5.
Появились таблицы, правила и чтение из базы; каталог и страница песни
лягут на них следующими шагами.

Главное решение — **уровень сложности хранится отдельной записью,
а не колонкой песни**:

```
песня        Nothing Else Matters · Metallica · E standard · 72 уд/мин
  └ вариант  Intermediate «Акустика, как в оригинале» · куратор Иван
      └ часть  Соло · 9:54–16:14
```

Почему не колонки `beginner_video_id` и подобные — в
[ADR-0012](docs/adr/0012-arrangements-model.md). Коротко: они ломаются
на первом же живом случае — два разбора одного уровня от разных
кураторов.

## Миграция

`drizzle/0004_songs.sql` — шесть новых таблиц и три перечисления:

```
songs                 песня
arrangements          вариант разбора: уровень, куратор, общее видео
arrangement_sections  части разбора
tags, taggables       метки и их привязка
attachments           табы, минусовки, конспекты
```

Существующие таблицы не меняются, ничего не удаляется.

## Демонстрационное содержимое

```bash
pnpm db:demo
```

Создаёт восемь песен. Набор подобран так, чтобы задеть все случаи,
на которых обычно ломается каталог:

| Песня                | Чем интересна для проверки                    |
| -------------------- | --------------------------------------------- |
| Nothing Else Matters | Три уровня сразу                              |
| Blackbird            | Два разбора одного уровня от разных кураторов |
| Кукушка              | Строй Drop D                                  |
| Пачка сигарет        | Каподастр, кириллица в адресе                 |
| Stairway to Heaven   | Черновик — участник видеть не должен          |
| Wish You Were Here   | Запланирована на будущее                      |
| Всё идёт по плану    | Песня вовсе без разборов                      |
| Hotel California     | Один продвинутый уровень                      |

Команду можно запускать повторно: демо-песни пересоздаются, остальное
не трогается. В производственной среде она отказывается работать.

## Что проверить

Экранов пока нет, поэтому проверка — через базу.

```bash
docker compose up -d && pnpm db:migrate && pnpm db:seed && pnpm db:demo
pnpm db:studio     # откроется просмотрщик базы в браузере
```

| Где                    | Ожидание                                                      |
| ---------------------- | ------------------------------------------------------------- |
| Таблица `songs`        | 9 записей: 7 опубликованных, 1 черновик, 1 запланированная    |
| Таблица `arrangements` | У Nothing Else Matters — три, у Blackbird — два одного уровня |
| `arrangement_sections` | Части с таймкодами, по 3 или 6 на вариант                     |
| Таблица `tags`         | 28 меток трёх видов                                           |
| Адреса песен           | `metallica-nothing-else-matters`, `kino-pachka-sigaret`       |

Повторный запуск `pnpm db:demo` не должен создавать дубликатов.

## Состав

**Новые файлы**

```
src/shared/db/enums.ts                    общие перечисления базы
src/modules/songs/schema.ts               песни, варианты, части
src/modules/songs/domain.ts               уровни, строи, части, длительности
src/modules/songs/domain.test.ts          39 тестов
src/modules/songs/catalog-filters.ts      разбор адреса каталога
src/modules/songs/catalog-filters.test.ts 28 тестов
src/modules/songs/types.ts                договор с интерфейсом
src/modules/songs/repository.ts           запросы к базе
src/modules/songs/service.ts              видимость по правам
src/modules/songs/strings.ts, index.ts
src/modules/taxonomy/schema.ts            метки и привязки
src/modules/taxonomy/catalog.ts           справочник жанров и техник
src/modules/taxonomy/catalog.test.ts      6 тестов
src/modules/taxonomy/index.ts
scripts/db-demo.ts                        демонстрационное содержимое
drizzle/0004_songs.sql                    миграция
docs/adr/0012-arrangements-model.md       обоснование модели
```

**Изменённые файлы**

```
src/modules/media/schema.ts        таблица материалов
src/modules/identity/profile.ts    жанры берутся из общего справочника
src/modules/identity/index.ts      наружу выведена сборка адреса фотографии
src/shared/db/schema.ts            подключены новые модули
drizzle.config.ts                  добавлен путь к общим перечислениям
package.json                       команда db:demo
docs/CHANGELOG.md, DATABASE.md, DECISIONS.md, ROADMAP.md
```

**Коммит**

```
feat(songs): add songs, arrangements and taxonomy data model
```
