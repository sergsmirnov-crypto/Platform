/**
 * Публичный вход в модуль журнала действий.
 *
 * Отвечает на вопрос «кто, что и когда сделал». Права проверяет модуль
 * `access`, кто человек — `identity`: журнал только фиксирует факт.
 */
export { recordAudit } from './service'
export type { AuditEvent } from './service'

export { AUDIT_ACTIONS } from './actions.catalog'
export type { AuditAction } from './actions.catalog'

export { getAuditLogPage, purgeOldAuditEntries } from './log'
export type { AuditEntry, AuditLogPage } from './log'
export {
  buildLogQuery,
  DEFAULT_LOG_FILTERS,
  hasActiveLogFilters,
  LOG_PERIODS,
  parseLogFilters,
} from './log-filters'
export type { LogEntityRef, LogFilters, LogPeriod } from './log-filters'
export { LOG_GROUPS } from './log-catalog'
export type { LogGroup } from './log-catalog'
export { logStrings } from './log-strings'

export { getSetting, setSetting } from './settings.service'
export { getEditableSettings, resetSetting, updateSetting } from './settings.admin'
export type { EditableSettings } from './settings.admin'
export {
  clubAboutSchema,
  isEditableSetting,
  MAX_CHAT_CARDS,
  renewUrlSchema,
  telegramChatsSchema,
} from './settings.schema'
export type { EditableSettingKey } from './settings.schema'
export { SETTING_KEYS, SETTING_DEFAULTS } from './settings.catalog'
export type {
  ClubAbout,
  ClubPoint,
  ClubQuestion,
  SettingKey,
  TelegramChatLink,
} from './settings.catalog'
