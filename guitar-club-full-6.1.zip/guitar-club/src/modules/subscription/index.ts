/**
 * Публичный вход в модуль подписок.
 *
 * Отвечает на один вопрос: положен ли этому человеку доступ к платному
 * содержимому. Кто он такой — знает модуль `identity`, что ему разрешено
 * делать — модуль `access`.
 */
export {
  applySubscriptionEvent,
  expireOutdatedEntitlements,
  getAccessStatus,
  grantAccessManually,
  hasActiveAccess,
  recordChannelMembership,
  revokeAccessManually,
  syncAccessFromKnownMembership,
} from './service'
export type { AccessStatus } from './service'

export { daysUntilLoss, grantsAccess } from './entitlement-policy'
export type {
  EntitlementEvent,
  EntitlementSource,
  EntitlementState,
  EntitlementStatus,
} from './entitlement-policy'

export { findSubscriptionHistory } from './repository'
export { subscriptionStrings } from './strings'
