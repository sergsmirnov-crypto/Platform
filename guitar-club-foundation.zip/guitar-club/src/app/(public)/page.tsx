import { PagePlaceholder } from '@/ui/patterns/page-placeholder'

export const metadata = { title: 'Вход в клуб' }

export default function HomePage() {
  return (
    <PagePlaceholder
      title="Вход в клуб"
      stage="Этап 2"
      description="Лендинг закрытого клуба и вход через Telegram."
    />
  )
}
