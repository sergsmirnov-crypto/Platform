import 'server-only'

import { eq } from 'drizzle-orm'

import { db } from '@/shared/db'

import { rolePermissions, userPermissions, userRoles } from './schema'

import type { RolePermissionRow, UserPermissionRow } from './effective-permissions'

/**
 * Запросы к базе, связанные с правами.
 *
 * Единственное место в модуле, где есть SQL. Всё остальное работает
 * с уже полученными данными.
 */

/** Права, которые человек получает через свои роли */
export async function findRolePermissions(userId: string): Promise<RolePermissionRow[]> {
  const rows = await db
    .select({
      permissionKey: rolePermissions.permissionKey,
      scope: rolePermissions.scope,
    })
    .from(userRoles)
    .innerJoin(rolePermissions, eq(rolePermissions.roleId, userRoles.roleId))
    .where(eq(userRoles.userId, userId))

  return rows
}

/** Персональные исключения человека */
export async function findUserPermissions(userId: string): Promise<UserPermissionRow[]> {
  const rows = await db
    .select({
      permissionKey: userPermissions.permissionKey,
      effect: userPermissions.effect,
      scope: userPermissions.scope,
    })
    .from(userPermissions)
    .where(eq(userPermissions.userId, userId))

  return rows
}
