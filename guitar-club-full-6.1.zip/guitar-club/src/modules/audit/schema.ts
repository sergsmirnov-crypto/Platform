import { bigserial, boolean, index, integer, jsonb, pgTable, text, uuid } from 'drizzle-orm/pg-core'

import { users } from '@/modules/identity/schema'
import { createdAt, timestampTz, updatedAt } from '@/shared/db/columns'

/**
 * Журнал действий и системные настройки.
 *
 * Практическая польза журнала — не в безопасности, а в разборе ситуаций
 * вроде «куда делся разбор Nothing Else Matters»: ответ находится
 * за десять секунд вместо часа переписки (PRD v0.3 §6).
 */

export const auditLog = pgTable(
  'audit_log',
  {
    id: bigserial('id', { mode: 'bigint' }).primaryKey(),

    /** Кто сделал. Может быть пустым, если действие выполнила система */
    actorId: uuid('actor_id').references(() => users.id, { onDelete: 'set null' }),

    /** Что сделал: 'song.publish', 'user.role_granted' */
    action: text('action').notNull(),
    entityType: text('entity_type'),
    entityId: text('entity_id'),

    /** Что именно изменилось: было и стало */
    diff: jsonb('diff').$type<Record<string, unknown>>(),

    ipHash: text('ip_hash'),
    createdAt: createdAt(),
  },
  (table) => [
    index('audit_log_actor_idx').on(table.actorId, table.createdAt),
    index('audit_log_entity_idx').on(table.entityType, table.entityId),
  ],
)

/**
 * Настройки платформы, которые меняются из интерфейса:
 * ссылки на чаты, тексты онбординга.
 */
export const appSettings = pgTable('app_settings', {
  key: text('key').primaryKey(),
  value: jsonb('value').$type<unknown>().notNull(),
  description: text('description'),
  updatedBy: uuid('updated_by').references(() => users.id, { onDelete: 'set null' }),
  updatedAt: updatedAt(),
})

/** Переключатели возможностей, управляемые без перезапуска приложения */
export const featureFlags = pgTable('feature_flags', {
  key: text('key').primaryKey(),
  enabled: boolean('enabled').notNull().default(false),
  /** Доля пользователей, для которых включено: 0–100 */
  rolloutPercent: integer('rollout_percent').notNull().default(0),
  description: text('description'),
  meta: jsonb('meta').$type<Record<string, unknown>>().notNull().default({}),
  updatedAt: updatedAt(),
})

/** Уведомления. Создаются платформой, доставляются через Telegram */
export const notifications = pgTable(
  'notifications',
  {
    id: bigserial('id', { mode: 'bigint' }).primaryKey(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),

    type: text('type').notNull(),
    title: text('title').notNull(),
    body: text('body'),
    actionUrl: text('action_url'),

    /** Куда отправлено: ['web', 'telegram'] */
    channels: text('channels').array().notNull().default([]),

    createdAt: createdAt(),
    sentAt: timestampTz('sent_at'),
    readAt: timestampTz('read_at'),
  },
  (table) => [index('notifications_user_idx').on(table.userId, table.createdAt)],
)
